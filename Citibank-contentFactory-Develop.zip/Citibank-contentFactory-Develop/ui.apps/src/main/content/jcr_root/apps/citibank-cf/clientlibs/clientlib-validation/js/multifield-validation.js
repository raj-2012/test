(function($, Coral){
    "use strict";
    let registry = $(window).adaptTo("foundation-registry");
    registry.register("foundation.validation.validator",{
        selector: "[data-validation=coral-multifield]",
        validate: function(element){
            let el=$(element);
            let max=el.data("max-item");
            let min= el.data("min-item");
            let items= el.children("coral-multifield-item").length;

            if(items>max){
                return "you can add only "+max+" items"
            }

            if(items<min){
                return "you need to add "+min+" items"
            }
        }
    });
})(jQuery, Coral);