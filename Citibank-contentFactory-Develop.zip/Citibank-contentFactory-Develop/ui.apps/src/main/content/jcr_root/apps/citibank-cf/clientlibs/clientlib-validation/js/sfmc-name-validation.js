(function($, Coral) {
    "use strict";
    let registry = $(window).adaptTo("foundation-registry");
    registry.register("foundation.validation.validator", {
        selector: "[data-validation=name-validate]",
        validate: function(element) {
            let el = $(element);
            let pattern=/[A-Z]/;
            let value=el.val();
            if(pattern.test(value)){
               return "Please use only lowercase letters.";
            }
        }
    });
})(jQuery, Coral); 