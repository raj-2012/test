$(document).ready(function () {
    filterSelectListItems();

    $(document).on('click', '.custom-dialog-class button', function () {
        filterSelectListItems();
    });

    function filterSelectListItems() {
        $('.coral-SelectList').each(function () {
            const $selectList = $(this);
            const $items = $selectList.find('.coral-SelectList-item');
            $items.each(function () {
                const $item = $(this);
                const itemText = $item.text().trim();
                if (itemText.endsWith('.theme')) {
                    $item.show();
                } else {
                    $item.hide();
                }
            });
            filterItems();
        });
    }
    function filterItems() {
        window.requestAnimationFrame(function () {
            $selectList.show();
        });

    }
});