$(document).ready(function () {

    const triggerBtn = $("#sfmcHandler");
    const $spinner = $("#sfmcSpinner");
    const jsonPath = $("#jsonPath").attr("data-path");

    // trigger post on click of the button
    $(triggerBtn).on("click", async function () {

        let jsonData, pageData;

        // retrieve JSON from DAM
        try {
            jsonData = await fetchJson();
            console.log('JSON fetched successfully');
        } catch (error) {
            console.error(error);
        }

        // call to fetch the inlined HTML content
        try {
            pageData = await fetchInlineHTML();
            console.log('Data fetched successfully');
        } catch (error) {
            console.error(error);
        }

        if (jsonData && pageData) {
            // construct payload 
            const payload = constructPayload(jsonData, pageData);
            
            payload && postDataToSFMC(payload);
        }

    });

    // show spinner 
    function showSpinner() {
        $spinner.removeClass("sfmc__spinner-wrapper--none");
    }

    // hide spinner
    function hideSpinner() {
        $spinner.addClass("sfmc__spinner-wrapper--none");
    }

    // fetch current url and modify it as per the parameter
    function generateModifiedPageURL(str) {
        const originalUrl = window.location.protocol + "//" + window.location.host + window.location.pathname;
        const newUrl = originalUrl.replace(".html", str);
        return newUrl;
    }

    // fetch Json file from DAM
    function fetchJson() {
        return new Promise((resolve, reject) => {
            $.ajax({
                type: "GET",
                url: jsonPath,
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                timeout: 10000,
                beforeSend: showSpinner,
            }).done(function (data) {
                if (data) {
                    resolve(data);
                }
                else {
                    reject(new Error(`Failed to fetch data`));
                }
            }).fail(function (jqXHR, textStatus, errorThrown) {
                reject(new Error(`Failed to fetch data: ${textStatus}, ${errorThrown}`));
            }).always(function () {
                hideSpinner();
            });
        });
    }

    // fetch the inline html of the page using the path of the current page
    function fetchInlineHTML() {
        return new Promise((resolve, reject) => {
            $.ajax({
                type: "GET",
                url: generateModifiedPageURL(".inline-styles.html"),
                contentType: "text/html;charset=utf-8",
                dataType: "html",
                timeout: 10000,
                beforeSend: showSpinner,
            }).done(function (data) {
                if (data) {
                    resolve(data);
                }
                else {
                    reject(new Error(`Failed to fetch data`));
                }
            }).fail(function (jqXHR, textStatus, errorThrown) {
                reject(new Error(`Failed to fetch data: ${textStatus}, ${errorThrown}`));
            }).always(function () {
                hideSpinner();
            });
        });
    }

    // Ajax call to post data to servlet
    function postDataToSFMC(payload) {
        $.ajax({
            url: generateModifiedPageURL(".createAsset.html"),
            type: 'POST',
            contentType: "application/json; charset=utf-8",
            data: JSON.stringify(payload),
            timeout: 10000,
            beforeSend: showSpinner,
        }).done(function (data) {
            if (data.id) {
                showSuccessMessage(data.id);
            }
        }).fail(function (jqXHR, textStatus, errorThrown) {
            if (jqXHR.responseJSON) {
                const data = jqXHR.responseJSON;
                const errMsg1 = `${data?.errorcode}, ${data?.validationErrors[0]?.errorcode}`;
                const errMsg2 = `${data?.message} - ${data?.validationErrors[0]?.message}`;
                showErrorMessage(errMsg1, errMsg2);
            }
            else {
                showErrorMessage(textStatus, errorThrown);
            }
        }).always(function () {
            hideSpinner();
        });
    }

    // extract all slots in the same hierarchy
    function extractSlots(doc) {

        let blocksWrapper;
        let blocksObj;
        let contentKey;
        let slotContentArr = new Array();
        let slotKeyArr = new Array();
        const $body = $(doc.body);

        $body.find(`[data-type="slot"]`).each(function () {

            const $content = $(this).clone();

            // extract the key of the block/slot
            contentKey = $content.attr("data-key");

            // design message
            const message = $content.attr("data-label") || "Drop blocks or content here";
            const messageString = `<p style="font-family: arial; color: #CCCCCC; font-size: 12px; font-weight: bold; text-align: center; display: flex; flex-direction: column; justify-content: center; height: 150px; padding: 10px; margin: 0; border: 1px dashed #CCCCCC;">${message}</p>`;

            const $slotContent = $content.find("table").first();

            [blocksWrapper, blocksObj] = extractBlocks($slotContent);

            const slotContentObj = {
                content: blocksWrapper,
                design: messageString,
                blocks: blocksObj,
                maxBlocks: 0,
                allowedBlocks: [],
                data: {
                    email: {
                        options: {
                            generateFrom: ""
                        }
                    }
                }
            };
    
            slotKeyArr.push(contentKey);
            slotContentArr.push(slotContentObj);

        });

        // remove slot content from doc
        doc.querySelectorAll(`[data-type="slot"]`).forEach((content) => {
            const slotContent = content.querySelector("table");
            slotContent.remove();
        });

        return [doc, slotKeyArr, slotContentArr];
    }


    // extract blocks in the same hierarchy in the slots
    function extractBlocks($slotContent) {

        let contentWrapperString = ""; // will contain the block/slot wrapper with their keys
        let contentObjs = new Object()
        let tableString;

        $slotContent.find(`[data-type="block"]`).each(function () {

            const $content = $(this).clone();

            // extract the key of the block/slot
            const contentKey = $content.attr("data-key");

            // design message
            const messageString = `<div class="default-design"><div style="width:100%;height:150px;"></div></div>`;

            const $table = $content.children("table").detach();

            contentWrapperString += $content.prop("outerHTML");

            tableString = $table.prop("outerHTML");

            const contentObj = {
                assetType: {
                    id: 197,
                    name: "htmlblock",
                },
                content: tableString,
                design: messageString,
                data: {
                    email: {
                        options: {
                            generateFrom: ""
                        }
                    }
                }
            };

            contentObjs[contentKey] = contentObj;
        });

        return [contentWrapperString, contentObjs];
    }

    // construct the payload and modify the read Json
    function constructPayload(jsonData, pageData) {

        const parser = new DOMParser();
        const doc = parser.parseFromString(pageData, 'text/html');
        
        const isPageStructureValid = validatePageStructure(doc);

        if (isPageStructureValid) {
            // title and description set via page properties
            const title = doc.title;
            const description = doc.querySelector(`meta[name="description"]`)?.getAttribute("content");
    
            // selected folder Id from page in edit mode
            const folderId = triggerBtn.attr("data-folder");

            // Global Ampscript
            const globalAmpScript = generateAmpScript(doc, "globalAmpScript");
            const templatePrefix = `${globalAmpScript}\n<div data-type="slot" data-key="slotLocalVariables" data-label="For setting up local variables and configuration of this email"></div>\n`;

            const head = doc.head;
            // Global CSS Ampscript
            const globalCssAmpScript = generateAmpScript(doc, "globalCssAmpScript");
            const globalStartComment = doc.createComment("GLOBAL CSS");
            const globalCssAmpScriptText = doc.createTextNode(globalCssAmpScript);
            const globalEndComment = doc.createComment("END OF GLOBAL CSS");
            head.appendChild(globalStartComment);
            head.appendChild(globalCssAmpScriptText);
            head.appendChild(globalEndComment);

            // Body CSS Ampscript
            const bodyCssAmpScript = generateAmpScript(doc, "bodyCssAmpScript");
            const bodyStartComment = doc.createComment("BODY CSS");
            const bodyCssAmpScriptText = doc.createTextNode(bodyCssAmpScript);
            const bodyEndComment = doc.createComment("END OF BODY CSS");
            head.appendChild(bodyStartComment);
            head.appendChild(bodyCssAmpScriptText);
            head.appendChild(bodyEndComment);

            let template; // will contain the DOM excluding the blocks 

            const [docUpdated, slotKeyArr, slotContentArr] = extractSlots(doc);

            // contains the DOM object after removing the blocks
            template = new XMLSerializer().serializeToString(docUpdated);

            // modify the json
            jsonData.category.id = folderId;
            jsonData.name = title;
            jsonData.description = description || title;
            jsonData.views.html.content = templatePrefix + template;
            jsonData.views.html.slots.slotLocalBodyContent = {};

            $.each(slotKeyArr, (i, slotKey) => {
                jsonData.views.html.slots[slotKey] = slotContentArr[i];
            });
            return (jsonData);
        }
        else {
            return null;
        }

    }

    // show error messages from ajax call
    function showErrorMessage(errorCode, errorMessage) {
        $(".messageInfo").hide(); // hide info message
        $("#errorCode").text(errorCode);
        $("#errorText").text(errorMessage);
        $("#errorMsg").show();
        $("#messageInfoWrapper").get(0).scrollIntoView({
            behavior: 'smooth',
            block: 'end',
            inline: "end",
        });
    }

    // show success messages from ajax call
    function showSuccessMessage(assetId) {
        $(".messageInfo").hide(); // hide info message
        $("#assetId").text(assetId);
        $("#successMsg").show();
        $("#messageInfoWrapper").get(0).scrollIntoView({
            behavior: 'smooth',
            block: 'end',
            inline: "end",
        });
    }

    function generateAmpScript(doc, type) {
        const id = doc.body.querySelector(`[data-amp-type="${type}"]`)?.getAttribute("data-amp-id");
        const ampScript = id ?`%%=ContentBlockbyId("${id}")=%%` : "";
        return ampScript;
    }

});

