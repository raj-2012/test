$(document).ready(function () {

    const jsonData = {
        "{(first_name|Valued Customer)}": "John",
        "{(first_name)}": "John",
        "{(last_name)}": "Smith",
        "{(text_variable2)}": 20,
        "{(text_variable_3)}": 500,
        "{(text_variable4)}": 1000,
        "{(text_variable6)}": 2022,
        "{(text_variable7)}": "30/09/2024",
        "{(acctlast4)}": 4012,
        "8888": 4012,
        "{(member_since)}": 2020,
        "7776": 2020,
        "{(sears_marketing_to_brand_matrix.brand_email_address)}": "test.mailforspam",
        "{(MessageMergeTime||d:yyyy)}": 2024,
        "{(sears_marketing_to_brand_matrix.live_richly_copy)}": "Live richly copy",
        "{(sears_marketing_to_brand_matrix.field1a)}": "This promotion is not transferable",
        "{(sears_marketing_to_brand_matrix.field1b)}": "All purchases must be made during the promotional period",
        "{(sears_marketing_to_brand_matrix.field1c)}": "The Sears Mastercard account must be current",
        "{(MessageMergeTime||d:MM/dd/yyyy)}": "08/30/2024",
        "{(mcell)}": "5:00 PM ET",
        "<XX/XX/XXXX>": "09/30/2024",
        "XX/XX/XXXX": "09/30/2024",
        "<9999999999>": 12345678901,
        "<X.XX>": 8.76,
        "<XX.XX>" : 98.76,
        "<FIRSTNAME>": "John Smith"
    };

    const selector = "p, span, li, a";

    $.each(jsonData, function (placeholder, value) {
        setValue(placeholder, value);
    });

    function encodeHtmlEntities(str) {
        return str.replace(/&/g, '&amp;')   // Replace & with &amp; first to avoid double encoding issues
            .replace(/</g, '&lt;')    // Replace < with &lt;
            .replace(/>/g, '&gt;')    // Replace > with &gt;
            .replace(/"/g, '&quot;')  // Replace " with &quot;
            .replace(/'/g, '&#39;');  // Replace ' with &#39;
    }

    function escapeString(input) {
        const specialChars = /[.*+?^${}()|[\]\\]/g;
        return input.replace(specialChars, '\\$&');
    }

    function setValue(placeholder, value) {
        $(selector).each(function () {
            let html = $(this).html();
            const escapedPlaceholder = escapeString(encodeHtmlEntities(placeholder));
            const regex = new RegExp(escapedPlaceholder, 'g');
            html = html.replace(regex, value);
            $(this).html(html);
        });
    }
});
