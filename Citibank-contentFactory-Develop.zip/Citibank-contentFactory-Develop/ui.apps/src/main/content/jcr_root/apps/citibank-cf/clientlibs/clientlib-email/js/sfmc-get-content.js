$(document).ready(function () {

    const $buttons = $(".ampScriptHandler");

    // Load and render all blocks from SFMC when the page is ready
    $buttons.each(function () {
        const $btn = $(this);
        if (isScriptInBlock($btn)) {
            fetchBlocksFromSFMC($btn);
        }
    });

    // Render a block from SFMC when a button is clicked
    $buttons.on("click", function () {
        const $btn = $(this);
        fetchBlocksFromSFMC($btn);
    });

    // Check if the script is authored in block
    function isScriptInBlock($btn) {
        const $wrapper = $btn.closest("[data-type]");
        if ($wrapper.attr("data-type") === "block") {
            return true;
        }
        else {
            $btn.hide();
            $btn.closest(".ampScriptWrapper").addClass("amp-script__container--error");
            $btn.closest(".ampScriptWrapper").find(".ampScriptError").attr("data-error", "incorrect-parent");
            $btn.closest(".ampScriptWrapper").find(".ampScriptError").text("AMPscript should be authored in a Block").show();
            return false;
        }
    }

    // Generate the modified endpoint URL based on the current page
    function generateModifiedPageURL(suffix) {
        const originalUrl = `${window.location.protocol}//${window.location.host}${window.location.pathname}`;
        return originalUrl.replace(".html", suffix);
    }

    // Display the loading spinner
    function showSpinner($spinner) {
        $spinner.removeClass("sfmc__spinner-wrapper--none");
    }

    // Hide the loading spinner
    function hideSpinner($spinner) {
        $spinner.addClass("sfmc__spinner-wrapper--none");
    }

    // Fetch blocks from SFMC via an AJAX call
    function fetchBlocksFromSFMC($btn) {
        const id = $btn.attr("data-amp-id");
        const $component = $btn.closest(".amp-script");
        const $contentWrapper = $component.find(".displayContent");
        const $spinner = $component.find(".ampSpinner");

        $.ajax({
            url: generateModifiedPageURL(`.createAsset.html?id=${id}`),
            type: 'GET',
            contentType: "application/json; charset=utf-8",
            timeout: 10000,
            beforeSend: () => {
                showSpinner($spinner);
                resetErrorMessage($component);
            },
        }).done((data) => {
            // Check if the fetched asset type is block
            if (data.assetType.id === 197 || data.assetType.id === 220) {
                insertContentIntoBlock(data, $contentWrapper);
                $component.find(".ampScriptSuccess").text(`Successfully fetched ${data.name}`).show();
            }
            else {
                showErrorMessage($component, `Asset with ID ${data.id} is ${data.assetType.displayName}`);
            }
        }).fail((jqXHR, textStatus, errorThrown) => {
            showErrorMessage($component, `${textStatus}: ${errorThrown}`);
        }).always(() => {
            hideSpinner($spinner);
        });
    }

    // Insert the fetched content into the DOM
    function insertContentIntoBlock(data, $contentWrapper) {
        const content = new DOMParser().parseFromString(data.content, "text/html");
        const $content  = $(content.body).html();
        $contentWrapper.empty().append($content);
    }

    // Display an error message in the specified element
    function showErrorMessage($el, message) {
        $el.find(".ampScriptWrapper").addClass("amp-script__container--error");
        $el.find(".ampScriptError").attr("data-error", "invalid-response");
        $el.find(".ampScriptError").text(message).show();
        $el.find(".ampScriptSuccess").text("").hide();
    }

    // Clear and hide error message
    function resetErrorMessage($el) {
        $el.find(".ampScriptWrapper").removeClass("amp-script__container--error");
        $el.find(".ampScriptError").removeAttr("data-error");
        $el.find(".ampScriptError").text("").hide();
        $el.find(".ampScriptSuccess").text("").hide();
    }
});

