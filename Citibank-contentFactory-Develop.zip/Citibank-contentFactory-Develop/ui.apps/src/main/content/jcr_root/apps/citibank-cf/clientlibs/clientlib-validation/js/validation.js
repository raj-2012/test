(function ($, window, document) {
    "use strict";

    $(document).on("foundation-contentloaded", function () {
        let registry = $(window).adaptTo("foundation-registry");

        registry.register("foundation.validation.validator", {
            selector: "[data-validation=txt-validate]",
            validate: function (el) {
                const element = $(el);
                const pattern = element.data('pattern');  // Get the pattern type from the data attribute
                const value = element.val();  // Get the value of the input field

                const patterns = {
                    alpha: /^[a-zA-Z\s]+$/,  // Allows only alphabets and spaces
                    lowerCase: /^[^A-Z]*$/,   // Ensures no uppercase letters
                };
                const testPattern = patterns[pattern];

                if (value.length && testPattern && !testPattern.test(value)) {

                    if (pattern === "alpha") {
                        return "The field must contain Alphabets Only.";
                    }
                    else if (pattern === "lowerCase") {
                        return "Please use lowercase characters only.";
                    }
                }
            }
        });
    });
})($, window, document);
