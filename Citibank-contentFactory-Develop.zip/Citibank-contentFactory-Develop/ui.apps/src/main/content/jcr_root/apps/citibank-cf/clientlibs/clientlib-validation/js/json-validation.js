(function ($, window, document) {
    "use strict";

    $(document).on("foundation-contentloaded", function () {
        let registry = $(window).adaptTo("foundation-registry");

        registry.register("foundation.validation.validator", {
            selector: "[data-foundation-validation=file-validate]",
            validate: function (el) {
                const element = $(el);
                const value = element.val();
                const jsonFilePattern = /^.*\.json$/;
                if (value.length && !jsonFilePattern.test(value)) {
                    return "Please select a .json file only";
                }
            }
        });
    });
})($, window, document);