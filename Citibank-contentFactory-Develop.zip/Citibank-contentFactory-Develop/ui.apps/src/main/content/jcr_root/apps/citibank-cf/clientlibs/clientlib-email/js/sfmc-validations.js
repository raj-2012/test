/* ------------------- VALIDATION ------------------- */

// validate page structure 
function validatePageStructure(doc) {

    let isPageStructureValid = true;

    const $body = $(doc.body);
    const $slots = $body.find(`[data-type="slot"]`);
    const $blocks = $body.find(`[data-type="block"]`);


    /** ------------ Global AMP script validations ------------ */

    // check to ensure 1 global variable is present 
    if (!hasAtMostOneAmpScriptOfType($body, "globalAmpScript")) {
        showValidationMessage("Global AMPscript", "Page can have only 1 Global AMPscript");
        isPageStructureValid = false;
        return isPageStructureValid;
    }
    if (!hasAtMostOneAmpScriptOfType($body, "globalCssAmpScript")) {
        showValidationMessage("Global CSS AMPscript", "Page can have only 1 Global CSS AMPscript");
        isPageStructureValid = false;
        return isPageStructureValid;
    }
    if (!hasAtMostOneAmpScriptOfType($body, "bodyCssAmpScript")) {
        showValidationMessage("Body CSS AMPscript", "Page can have only 1 Body CSS AMPscript");
        isPageStructureValid = false;
        return isPageStructureValid;
    }

    // check to ensure all ampscripts are defined in blocks and has fetched content
    const [scriptFlag, wrapperName, errorMessage] = checkScriptsInSlots()
    if (!scriptFlag) {
        showValidationMessage(wrapperName, errorMessage);
        isPageStructureValid = false;
        return isPageStructureValid;
    }

    /** ------------ SLOT validations ------------ */

    // check to ensure all the slots are in the same hierarchy
    const [hasParallelSlots, parallelSlotName] = checkParallelSlotHierarchy($slots);
    if (!hasParallelSlots) {
        showValidationMessage(parallelSlotName, "Slot is not parallel to other slots or is nested.");
        isPageStructureValid = false;
        return isPageStructureValid;
    }

    // check to ensure all the slots are not nested
    const [hasNestedSlots, nestedSlotName] = checkNestedHierarchy($slots);
    if (hasNestedSlots) {
        showValidationMessage(nestedSlotName, "Nested slots present.");
        isPageStructureValid = false;
        return isPageStructureValid;
    }

    // check to ensure all the slots have blocks in them
    const [isSlotEmpty, emptySlotName] = checkSlotContent($slots, $blocks);
    if (isSlotEmpty) {
        showValidationMessage(emptySlotName, "Slot does not have any blocks");
        isPageStructureValid = false;
        return isPageStructureValid;
    }

    // check for duplicate slot names 
    const [hasDuplicateSlotNames, duplicateSlotNames] = checkDuplicateNames($slots);
    if (hasDuplicateSlotNames) {
        showValidationMessage(duplicateSlotNames, "Slot names are duplicate");
        isPageStructureValid = false;
        return isPageStructureValid;
    }

    /** ------------ BLOCK validations ------------ */

    // check to ensure all the blocks are in the same hierarchy
    const [hasParallelBlocks, parallelBlockName] = checkParallelBlockHierarchy($slots);
    if (!hasParallelBlocks) {
        showValidationMessage(parallelBlockName, "Block is not parallel to other blocks in slot or is nested.");
        isPageStructureValid = false;
        return isPageStructureValid;
    }

    // check to ensure all the blocks are not nested under blocks
    const [hasNestedBlocks, nestedBlockName] = checkNestedHierarchy($blocks);
    if (hasNestedBlocks) {
        showValidationMessage(nestedBlockName, "Block is nested in a another block.");
        isPageStructureValid = false;
        return isPageStructureValid;
    }

    // check to ensure all the blocks are descendants of a slot.
    const [hasSlotParent, nonSlotParentBlockName] = checkBlockInsideSlot($blocks);
    if (!hasSlotParent) {
        showValidationMessage(nonSlotParentBlockName, "Block is not a child of a slot.");
        isPageStructureValid = false;
        return isPageStructureValid;
    }

    // check for duplicate block names 
    const [hasDuplicateBlockNames, duplicateBlockNames] = checkDuplicateNames($blocks);
    if (hasDuplicateBlockNames) {
        showValidationMessage(duplicateBlockNames, "Block names are duplicate");
        isPageStructureValid = false;
        return isPageStructureValid;
    }

    return isPageStructureValid;
}

// get the grand parent of the block or slot if it is wrapped in another element, otherwise immediate parent
function getRelevantParent($element) {
    return $element.parent(".container.responsivegrid").length ? $element.parent().parent() : $element.parent();
}

// check if slots are parallel to one another
function checkParallelSlotHierarchy($slots) {

    let areParallel = true;
    let location;

    $slots.each(function () {
        const $slot = $(this);
        const $parent = getRelevantParent($slot);
        $slots.not($slot).each(function () {
            if (!getRelevantParent($(this)).is($parent)) {
                location = $(this).attr("data-key");
                areParallel = false;
                return false;
            }
        });
        return conditionalExit(!areParallel);
    });

    return [areParallel, location];
}

// check if blocks in a slot are parallel to one another
function checkParallelBlockHierarchy($slots) {

    let areParallel = true;
    let location;

    $slots.each(function () {
        const $slot = $(this);
        const $blocks = $slot.find(`[data-type="block"]`);
        $blocks.each(function () {
            const $block = $(this);
            const $parent = getRelevantParent($block);
            $blocks.not($block).each(function () {
                if (!getRelevantParent($(this)).is($parent)) {
                    location = $(this).attr("data-key");
                    areParallel = false;
                    return false;
                }
            });
            return conditionalExit(!areParallel);
        });
        return conditionalExit(!areParallel);
    });

    return [areParallel, location];
}

// check if any nested blocks/slots are present
function checkNestedHierarchy($sections) {

    let nestedSections = false;
    let location;

    $sections.each(function () {
        const $section = $(this);
        $sections.not($section).each(function () {
            if ($(this).closest($section).length > 0) {
                location = $section.attr("data-key");
                nestedSections = true;
                return false;
            }
        });
        return conditionalExit(nestedSections);
    });

    return [nestedSections, location];
}

// check if slot contains blocks
function checkSlotContent($slots, $blocks) {

    let isSlotEmpty = false;
    let location;

    $slots.each(function () {
        const $slot = $(this);
        if (!$slot.find($blocks).length) {
            location = $slot.attr("data-key");
            isSlotEmpty = true;
            return false;
        }
    });

    return [isSlotEmpty, location];
}

// check if blocks are wrapped in slots
function checkBlockInsideSlot($blocks) {
    let hasSlotParent = true;
    let location;

    $blocks.each(function () {
        const $block = $(this);
        if (!$block.closest(`[data-type="slot"]`).length) {
            location = $block.attr("data-key");
            hasSlotParent = false;
            return false;
        }
    });

    return [hasSlotParent, location]

}

// check duplicate names
function checkDuplicateNames($content) {

    const duplicates = new Object();
    let hasDuplicates = false;
    let duplicatesNames = new Array();

    $content.each(function () {
        const name = $(this).attr("data-key");
        duplicates[name] = duplicates[name] ? duplicates[name] + 1 : 1;
    });

    Object.entries(duplicates).forEach(function (name) {
        if (name[1] > 1) {
            duplicatesNames.push(name[0]);
            hasDuplicates = true;
        }
    });

    return [hasDuplicates, duplicatesNames.toString()];

}

// show validation message
function showValidationMessage(name, errorMessage) {
    $(".messageInfo").hide(); // hide info message
    $("#errorCode").text(name);
    $("#errorText").text(errorMessage);
    $("#errorMsg").show();
    $("#messageInfoWrapper").get(0).scrollIntoView({
        behavior: 'smooth',
        block: 'end',
        inline: "end",
    });
}

// check if any AMscripts are present in slots - not using inline HTML
function checkScriptsInSlots() {
    let flag = true;
    let wrapperName;
    let message;
    const $errors = $(".ampScriptError");
    $errors.each(function () {
        const $error = $(this);
        const $wrapper = $error.closest("[data-type]");
        const errorType = $error.attr("data-error");
        if (errorType === "incorrect-parent" || errorType === "invalid-response") {
            flag = false;
            wrapperName = $wrapper.attr("data-key") || "AMPscript";
            message = errorType === "incorrect-parent" ? "AMPscript authored outside block." : "AMPscript is not able to fetch content.";
            return false;
        }
    });
    return [flag, wrapperName, message];
}

function hasAtMostOneAmpScriptOfType($body, type) {
    const $ampScriptType = $body.find(`[data-amp-type="${type}"]`);
    return $ampScriptType.length <= 1;
}

function conditionalExit(flag) {
    if (flag) {
        return false;
    }
}


/* ------------------- VALIDATION END ------------------- */