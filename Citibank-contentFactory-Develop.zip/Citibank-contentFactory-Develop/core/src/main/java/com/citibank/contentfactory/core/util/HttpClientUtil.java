package com.citibank.contentfactory.core.util;

import org.apache.http.client.config.RequestConfig;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.osgi.services.HttpClientBuilderFactory;

/**
 * Utility class for creating HTTP clients with custom configurations.
 */
public class HttpClientUtil {

    private HttpClientUtil() {
        throw new IllegalStateException("Http ClientUtil class");
    }

    /**
     * Creates a CloseableHttpClient with custom timeout settings.
     *
     * @param clientBuilderFactory The HttpClientBuilderFactory to build the HTTP client.
     * @param socketTimeout        The socket timeout in milliseconds.
     * @param connectTimeout       The connection timeout in milliseconds.
     * @return The configured CloseableHttpClient.
     */
    public static CloseableHttpClient createHttpClient(HttpClientBuilderFactory clientBuilderFactory, int socketTimeout, int connectTimeout) {
        // Build the HTTP client with custom timeout settings
        return clientBuilderFactory.newBuilder()
                .setDefaultRequestConfig(RequestConfig.custom()
                        .setSocketTimeout(socketTimeout)   // Set socket timeout
                        .setConnectTimeout(connectTimeout) // Set connection timeout
                        .build())
                .build();
    }
}

