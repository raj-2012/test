package com.citibank.contentfactory.core.service;

//This service class contains EmailHtmlDump Configurations

public interface EmailHtmlDumpService {
    String emailHtmlDumpFolderPath();
}
