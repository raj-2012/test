package com.citibank.contentfactory.core.servlets;

import java.io.IOException;
import java.util.Date;
import javax.jcr.Session;
import javax.servlet.Servlet;
import javax.servlet.http.HttpServletResponse;

import com.citibank.contentfactory.core.service.GETApiService;
import com.citibank.contentfactory.core.service.POSTAPIService;
import com.citibank.contentfactory.core.service.SFMCService;
import com.citibank.contentfactory.core.util.ConstantUtils;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.servlets.annotations.SlingServletResourceTypes;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ModifiableValueMap;
import org.apache.sling.api.resource.PersistenceException;

/**
 * Servlet to handle POST requests for creating an asset in SFMC (Salesforce Marketing Cloud).
 * This servlet is responsible for obtaining the access token and sending content to SFMC.
 */

@Component(service = {Servlet.class}, immediate = true)
@SlingServletResourceTypes(
        resourceTypes = ConstantUtils.SLING_SERVLET_DEFAULT,
        selectors = "createAsset",
        extensions = ConstantUtils.HTML,
        methods = {HttpConstants.METHOD_GET, HttpConstants.METHOD_POST}
)
public class SFMCAccessTokenServlet extends SlingAllMethodsServlet {

    // Logger instance for logging any errors or debug information
    private static final Logger LOG = LoggerFactory.getLogger(SFMCAccessTokenServlet.class);

    // Reference to SFMCService for accessing client credentials and URLs
    @Reference
    private transient SFMCService sfmcService;

    // Reference to POSTAPIService for handling POST requests to SFMC
    @Reference
    private transient POSTAPIService postServiceAPI;

    @Reference
    private transient GETApiService getApiService;

    @Override
    protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
        String payLoad = null;
        String pagePath = null;
        // Read the request payload if it's present
        if (request.getReader() != null) {
            payLoad = IOUtils.toString(request.getReader());
            pagePath = request.getRequestPathInfo().getResourcePath();  // Get the page path
        }

        // Validate that the payload is not blank or null
        if (StringUtils.isBlank(payLoad)) {
            LOG.info("Payload is empty or null.");
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);  // Return 400 Bad Request if payload is invalid
            return;
        }

        // Retrieve the user from the Session via ResourceResolver
        String currentUser = getUserFromSession(request);

        // Retrieve the SFMC access token for authorization
        String accessToken = getSFMCAuthToken(response);
        if (StringUtils.isBlank(accessToken)) {
            LOG.info("Failed to retrieve SFMC Auth Token.");
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);  // Return 401 Unauthorized
            return;
        }

        // Update the page's properties with "emailApprovedBy"
        if (updatePageProperties(request, pagePath, currentUser)) {
            LOG.info("Successfully updated page properties for path: {}", pagePath);
        } else {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);  // Return 500 if property update fails
            return;
        }

        // Send the payload to the POST API service using the access token
        postServiceAPI.getPOSTAPIResponse(response, accessToken, payLoad);

        // Log success after sending the request
        LOG.info("User '{}' successfully posted content to SFMC at {}", currentUser, new Date());
    }

    @Override
    protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
        String id = null;
        // Read the request payload if it's present
        if (request.getParameter("id") != null) {
            id = request.getParameter("id");  // Get the page path
        }

        // Retrieve the SFMC access token for authorization
        String accessToken = getSFMCAuthToken(response);
        if (StringUtils.isBlank(accessToken)) {
            LOG.info("Failed to retrieve SFMC Auth Token.");
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);  // Return 401 Unauthorized
            return;
        }

        // Send the payload to the POST API service using the access token
        getApiService.getGETAPIResponse(response, accessToken, id);
    }

    /**
     * Helper method to retrieve the user from the Session using ResourceResolver.
     * This method attempts to get the user from the JCR session first, then tries to retrieve the remote user.
     *
     * @param request The Sling HTTP servlet request object.
     * @return The user ID as a string.
     */
    private String getUserFromSession(SlingHttpServletRequest request) {
        String userId = "Unknown User";  // Default if user not found

        // Adapt ResourceResolver to Session to retrieve the user ID
        Session session = request.getResourceResolver().adaptTo(Session.class);
        if (session != null) {
            userId = session.getUserID();  // Get the user ID from the session
        }

        // Try to retrieve the remote user from the request attributes if session is not available
        String remoteUser = (String) request.getAttribute("org.osgi.service.http.authentication.remote.user");
        if (StringUtils.isNotBlank(remoteUser)) {
            userId = remoteUser;  // Override with remote user if available
        }

        return userId;
    }

    /**
     * Helper method to update the page properties.
     * Adds the "emailApprovedBy" property with the current user to the page node.
     *
     * @param request     The Sling HTTP servlet request object.
     * @param pagePath    The path of the page to update.
     * @param currentUser The current user to set as the approver.
     * @return true if the properties were successfully updated, false otherwise.
     */
    private boolean updatePageProperties(SlingHttpServletRequest request, String pagePath, String currentUser) {
        ResourceResolver resourceResolver = request.getResourceResolver();
        try {
            // Get the resource (page) from the path
            Resource pageResource = resourceResolver.getResource(pagePath + ConstantUtils.SLASH+ConstantUtils.JCR_CONTENT);
            if (pageResource != null) {
                // Get the page's properties
                ModifiableValueMap properties = pageResource.adaptTo(ModifiableValueMap.class);
                if (properties != null) {
                    // Add or update the "emailApprovedBy" property
                    properties.put("emailApprovedBy", currentUser);
                    // Save the changes
                    resourceResolver.commit();
                    return true;  // Successfully updated properties
                }
            }
        } catch (PersistenceException e) {
            LOG.error("Error updating page properties at {}: {}", pagePath, e.getMessage());
        }
        return false;
    }

    /**
     * Helper method to retrieve the Salesforce Marketing Cloud (SFMC) access token.
     * Constructs the authentication payload and calls the POSTAPIService to get the access token.
     *
     * @param response The Sling HTTP servlet response object used to handle any errors.
     * @return The access token as a string.
     */
    private String getSFMCAuthToken(SlingHttpServletResponse response) {
        // Create the authentication payload using client credentials
        ObjectMapper objectMapper = new ObjectMapper();
        ObjectNode authPayload = objectMapper.createObjectNode();
        authPayload.put(ConstantUtils.GRANT_TYPE, ConstantUtils.CLIENT_CREDENTIALS);
        authPayload.put(ConstantUtils.CLIENT_ID, sfmcService.clientId());
        authPayload.put(ConstantUtils.CLIENT_SECRET, sfmcService.clientSecret());
        authPayload.put(ConstantUtils.ACCOUNT_ID, sfmcService.accountId());
        // Convert the authentication payload to a JSON string
        String payloadString = authPayload.toString();
        // Call the POSTAPIService to retrieve the access token
        return postServiceAPI.getAccessTokenPOSTAPI(response, payloadString);
    }
}
