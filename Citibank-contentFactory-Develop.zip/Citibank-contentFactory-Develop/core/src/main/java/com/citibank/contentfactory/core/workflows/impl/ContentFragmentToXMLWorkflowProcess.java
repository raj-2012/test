package com.citibank.contentfactory.core.workflows.impl;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamWriter;

import com.adobe.granite.workflow.WorkflowException;
import com.adobe.granite.workflow.WorkflowSession;
import com.adobe.granite.workflow.exec.WorkItem;
import com.adobe.granite.workflow.exec.WorkflowProcess;
import com.adobe.granite.workflow.metadata.MetaDataMap;
import com.citibank.contentfactory.core.config.ContentFragmentToXMLWorkflowConfig;
import com.citibank.contentfactory.core.util.ConstantUtils;
import com.citibank.contentfactory.core.workflows.ContentFragmentToXMLWorkflow;
import com.day.cq.dam.api.AssetManager;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.PersistenceException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.engine.SlingRequestProcessor;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.metatype.annotations.Designate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

// OSGi component definition for the workflow process, converting content fragments to XML
@Component(service = WorkflowProcess.class, property = { "process.label=Convert Content Fragment to XML With Variations" })
@Designate(ocd = ContentFragmentToXMLWorkflowConfig.class)
public class ContentFragmentToXMLWorkflowProcess implements WorkflowProcess, ContentFragmentToXMLWorkflow {


    // Logger for logging errors or information
    private static final Logger LOG = LoggerFactory.getLogger(ContentFragmentToXMLWorkflowProcess.class);

    // Target folder path to store generated XML files
    private String targetFolderPath;

    // Injected ResourceResolverFactory to obtain service resource resolver
    @Reference
    private ResourceResolverFactory resourceResolverFactory;

    @Reference
    private SlingRequestProcessor slingRequestProcessor;

    // Method to activate or update the configuration, setting the target folder path
    @Activate
    @Modified
    protected void activate(ContentFragmentToXMLWorkflowConfig config) {
        this.targetFolderPath = config.targetFolderPath();
    }

    // Main workflow process execution method
    @Override
    public void execute(WorkItem workItem, WorkflowSession workflowSession, MetaDataMap metaDataMap)
            throws WorkflowException {

        try (ResourceResolver resourceResolver = getResourceResolver()) { // Try-with-resources to auto-close resolver
            if (resourceResolver != null) {
                // Get the path of the workflow payload (the content fragment)
                String payloadPath = getPayloadPath(workItem);
                // Process the content fragment and generate XML
                processContentFragment(resourceResolver, payloadPath);
            } else {
                LOG.error("Failed to obtain a ResourceResolver using the system user.");
            }

        } catch (LoginException e) {
            throw new WorkflowException("Failed to obtain a valid ResourceResolver.", e);
        } catch (PersistenceException e) {
            throw new WorkflowException("Persistence error occurred.", e);
        } catch (IOException e) {
            throw new WorkflowException("I/O error occurred.", e);
        } catch (XMLStreamException e) {
            throw new WorkflowException("XML generation error occurred.", e);
        } catch (RepositoryException e) {
            throw new RuntimeException("Repository error occurred.", e);
        }
    }

    // Helper method to obtain a service user resource resolver
    private ResourceResolver getResourceResolver() throws LoginException {
        Map<String, Object> params = new HashMap<>();
        params.put(ResourceResolverFactory.SUBSERVICE, ConstantUtils.DATAWRITER); // Use the DATAWRITER system user
        return resourceResolverFactory.getServiceResourceResolver(params);
    }

    // Helper method to retrieve the payload path from the WorkItem
    private String getPayloadPath(WorkItem workItem) {
        return workItem.getWorkflowData().getPayload().toString(); // Retrieve the payload path as a string
    }

    // Processes the content fragment located at the provided payload path
    private void processContentFragment(ResourceResolver resourceResolver, String payloadPath)
            throws  XMLStreamException, IOException, RepositoryException {
        Resource contentFragment = resourceResolver.getResource(payloadPath);
        if (contentFragment != null) {
            // Locate the variations node under jcr:content/data
            Resource variationsNode = contentFragment.getChild(ConstantUtils.JCR_CONTENT + "/data");
            if (variationsNode != null) {
                // Process the variations of the content fragment
                processVariations(resourceResolver, variationsNode, payloadPath);
            } else {
                LOG.error("No variations found under jcr:content/data.");
            }
        } else {
            LOG.error("Content Fragment not found at path: {}", payloadPath);
        }
    }

    // Method to process each variation in the content fragment
    @Override
    public void processVariations(ResourceResolver resourceResolver, Resource variationsNode, String payloadPath)
            throws XMLStreamException, IOException, RepositoryException {
        for (Resource variation : variationsNode.getChildren()) {
            // For each variation, generate XML and save it to the DAM
            String variationName = variation.getName();
            String xmlData = generateXMLFromContentFragment(variation);
            saveXMLToDAM(resourceResolver, xmlData, payloadPath, variationName);
        }
        simulateRequestProcessing(resourceResolver, payloadPath);
    }

    // Method to generate XML from a content fragment variation
    @Override
    public String generateXMLFromContentFragment(Resource contentFragmentVariation) throws XMLStreamException, PersistenceException {
        StringWriter stringWriter = new StringWriter(); // Writer for the XML output
        XMLOutputFactory outputFactory = XMLOutputFactory.newInstance(); // XML output factory
        XMLStreamWriter xmlWriter = outputFactory.createXMLStreamWriter(stringWriter);

        // Start writing the XML document
        xmlWriter.writeStartDocument("UTF-8", "1.0");
        xmlWriter.writeStartElement("contentFragment");

        // Loop through all properties of the content fragment variation
        for (String key : contentFragmentVariation.getValueMap().keySet()) {
            if (isSystemField(key) || isUnnecessaryField(key)) {
                continue; // Skip system and unnecessary fields like 'testing'
            }

            Object fieldValue = contentFragmentVariation.getValueMap().get(key);
            if (fieldValue != null) {
                xmlWriter.writeStartElement(key);  // Write the field name as an element

                if (fieldValue instanceof Object[]) {
                    // Handle multi-value fields (arrays)
                    writeArrayField(xmlWriter, (Object[]) fieldValue);
                } else if (fieldValue instanceof Iterable) {
                    // Handle iterable fields (e.g., lists)
                    writeIterableField(xmlWriter, (Iterable<?>) fieldValue);
                } else if (fieldValue instanceof String && isContentFragmentReference((String) fieldValue, contentFragmentVariation.getResourceResolver())) {
                    // Handle nested content fragment references
                    Resource nestedContentFragment = contentFragmentVariation.getResourceResolver().getResource((String) fieldValue + "/jcr:content/data/master");
                    if (nestedContentFragment != null) {
                        processNestedContentFragment(xmlWriter, nestedContentFragment); // Recursively process the nested fragment
                    }
                } else {
                    writeField(xmlWriter, fieldValue);  // Write the field value
                }

                xmlWriter.writeEndElement();  // Close the field element
            } else {
                LOG.warn("Field '{}' not found in the content fragment variation.", key);
            }
        }

        xmlWriter.writeEndElement();  // Close the contentFragment element
        xmlWriter.writeEndDocument();
        xmlWriter.flush();
        xmlWriter.close();

        return stringWriter.toString(); // Return the generated XML as a string
    }

    // Method to recursively process nested content fragments
    private void processNestedContentFragment(XMLStreamWriter xmlWriter, Resource nestedContentFragment) throws XMLStreamException {
        xmlWriter.writeStartElement("nestedContentFragment");

        // Loop through all properties of the nested content fragment
        for (String nestedKey : nestedContentFragment.getValueMap().keySet()) {
            if (isSystemField(nestedKey) || isUnnecessaryField(nestedKey)) {
                continue; // Skip system and unnecessary fields
            }

            Object nestedFieldValue = nestedContentFragment.getValueMap().get(nestedKey);
            if (nestedFieldValue != null) {
                xmlWriter.writeStartElement(nestedKey);  // Write the nested field name

                if (nestedFieldValue instanceof Object[]) {
                    writeArrayField(xmlWriter, (Object[]) nestedFieldValue);  // Handle arrays
                } else if (nestedFieldValue instanceof Iterable) {
                    writeIterableField(xmlWriter, (Iterable<?>) nestedFieldValue);  // Handle lists
                } else {
                    writeField(xmlWriter, nestedFieldValue);  // Write the nested field value
                }

                xmlWriter.writeEndElement();  // Close the nested field element
            }
        }

        xmlWriter.writeEndElement();  // Close the nestedContentFragment element
    }

    // Method to determine if a field is unnecessary for XML generation (e.g., "testing" fields)
    private boolean isUnnecessaryField(String fieldName) {
        return "testing".equals(fieldName); // Example of skipping unnecessary fields
    }

    // Method to check if a field points to another content fragment
    private boolean isContentFragmentReference(String path, ResourceResolver resourceResolver) {
        Resource resource = resourceResolver.getResource(path + "/jcr:content/data/master");
        return resource != null;  // Return true if the resource exists
    }

    // Method to write an array field in the XML
    private void writeArrayField(XMLStreamWriter xmlWriter, Object[] array) throws XMLStreamException {
        for (Object item : array) {
            xmlWriter.writeStartElement("value");
            xmlWriter.writeCharacters(item.toString());
            xmlWriter.writeEndElement();
        }
    }

    // Method to write an iterable field (e.g., list) in the XML
    private void writeIterableField(XMLStreamWriter xmlWriter, Iterable<?> iterable) throws XMLStreamException {
        for (Object item : iterable) {
            xmlWriter.writeStartElement("value");
            xmlWriter.writeCharacters(item.toString());
            xmlWriter.writeEndElement();
        }
    }

    // Method to write a single field value in the XML
    private void writeField(XMLStreamWriter xmlWriter, Object fieldValue) throws XMLStreamException {
        if (fieldValue instanceof String) {
            String filteredValue = filterContent((String) fieldValue);
            xmlWriter.writeCharacters(filteredValue);
        } else if (fieldValue instanceof Boolean || fieldValue instanceof Double) {
            xmlWriter.writeCharacters(fieldValue.toString());
        } else if (fieldValue instanceof Date) {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
            xmlWriter.writeCharacters(dateFormat.format((Date) fieldValue));
        } else if (fieldValue instanceof Calendar) {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
            xmlWriter.writeCharacters(dateFormat.format(((Calendar) fieldValue).getTime()));
        } else {
            xmlWriter.writeCharacters(fieldValue.toString());
        }
    }

    // Method to filter content for invalid characters and remove XML tags
    private String filterContent(String content) {
        String decodedContent = org.apache.commons.text.StringEscapeUtils.unescapeHtml4(content);
        decodedContent = decodedContent.replaceAll("[^\\x20-\\x7E]", "");  // Remove non-ASCII characters
        decodedContent = decodedContent.replaceAll("<\\?xml[^>]+\\?>", "");  // Remove XML declarations
        decodedContent = decodedContent.replaceAll("<[^>]+>", "");  // Remove HTML or XML tags if necessary
        return decodedContent;
    }

    // Method to save the generated XML to the DAM
    @Override
    public void saveXMLToDAM(ResourceResolver resourceResolver, String xmlData, String payloadPath, String variationName)
            throws PersistenceException, RepositoryException {
        String fileName = payloadPath.substring(payloadPath.lastIndexOf('/') + 1) + "_" + variationName + ".xml";
        String targetFolder = targetFolderPath;

        // Retrieve or create the target folder in the DAM
        Resource targetFolderResource = resourceResolver.getResource(targetFolder);
        if (targetFolderResource == null) {
            createFolderIfNotExists(resourceResolver, targetFolder);
            targetFolderResource = resourceResolver.getResource(targetFolder);
        }

        // Save the XML as a DAM asset if the folder exists
        if (targetFolderResource != null) {
            AssetManager assetManager = resourceResolver.adaptTo(AssetManager.class);
            if (assetManager != null) {
                assetManager.createAsset(targetFolder + "/" + fileName, new ByteArrayInputStream(xmlData.getBytes()),
                        ConstantUtils.APPLICATION_XML, true);
            } else {
                LOG.error("Asset Manager not available. Cannot save XML.");
            }
        } else {
            LOG.error("Failed to create or retrieve target folder at path: {}", targetFolder);
        }
    }

    // Helper method to create a folder structure in the DAM if it doesn't exist
    private void createFolderIfNotExists(ResourceResolver resourceResolver, String folderPath)
            throws PersistenceException, RepositoryException {
        String[] pathSegments = folderPath.split("/");
        String currentPath = ConstantUtils.CONTENT_DAM;
        for (int i = 3; i < pathSegments.length; i++) {
            currentPath += "/" + pathSegments[i];
            Resource folder = resourceResolver.getResource(currentPath);
            if (folder == null) {
                Node parentNode;
                try {
                    parentNode = resourceResolver.getResource(currentPath.substring(0, currentPath.lastIndexOf('/')))
                            .adaptTo(Node.class);
                    if (parentNode != null) {
                        parentNode.addNode(pathSegments[i], "sling:OrderedFolder");
                        resourceResolver.commit();
                        LOG.info("Created folder: {}", currentPath);
                    }
                } catch (RepositoryException e) {
                    throw new RepositoryException("Failed to create folder.", e);
                }
            }
        }
    }

    // Helper method to identify system fields that should be excluded from XML
    private boolean isSystemField(String fieldName) {
        String[] systemFields = { ConstantUtils.JCR_PRIMARY_TYPE, ConstantUtils.JCR_MIXIN_TYPES,
                ConstantUtils.CQ_LAST_MODIFIED, ConstantUtils.CQ_LAST_MODIFIED_BY, ConstantUtils.JCR_CREATED,
                ConstantUtils.JCR_CREATED_BY };

        for (String systemField : systemFields) {
            if (fieldName.startsWith(systemField) || fieldName.contains("@")) {
                return true;
            }
            if (fieldName.startsWith(systemField) || fieldName.contains("cq:tags")) {
                return true;
            }
        }
        return false;
    }

    private void simulateRequestProcessing(ResourceResolver resourceResolver, String payloadPath) throws IOException {
        try {
            HttpServletRequest request = (HttpServletRequest) new MockHttpServletRequest(resourceResolver, payloadPath);
            HttpServletResponse response = (HttpServletResponse) new MockHttpServletResponse();

            slingRequestProcessor.processRequest(request, response, resourceResolver);

            LOG.info("Simulated request processing for payload: {}", payloadPath);

        } catch (IOException e) {
            throw new IOException(e);
        } catch (ServletException e) {
            throw new RuntimeException(e);
        }
    }

    private static class MockHttpServletRequest extends SlingAllMethodsServlet {
        public final transient ResourceResolver resourceResolver;
        public final String requestURI;

        public MockHttpServletRequest(ResourceResolver resourceResolver, String requestURI) {
            this.resourceResolver = resourceResolver;
            this.requestURI = requestURI;
        }
    }

    public static class MockHttpServletResponse extends SlingAllMethodsServlet {

    }
}