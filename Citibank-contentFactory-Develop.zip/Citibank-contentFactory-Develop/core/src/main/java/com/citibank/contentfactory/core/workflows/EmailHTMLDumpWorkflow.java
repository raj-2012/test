package com.citibank.contentfactory.core.workflows;

import com.adobe.granite.workflow.WorkflowException;
import com.adobe.granite.workflow.WorkflowSession;
import com.adobe.granite.workflow.exec.WorkflowProcess;
import com.adobe.granite.workflow.exec.WorkItem;
import com.adobe.granite.workflow.metadata.MetaDataMap;
import com.citibank.contentfactory.core.service.EmailHtmlDumpService;
import com.citibank.contentfactory.core.util.ConstantUtils;
import com.day.cq.wcm.api.WCMMode;
import org.apache.commons.lang.StringUtils;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.day.cq.contentsync.handler.util.RequestResponseFactory;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.engine.SlingRequestProcessor;
import com.day.cq.dam.api.AssetManager;
import com.day.cq.dam.api.Asset;
import javax.jcr.Session;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

@Component(service = WorkflowProcess.class, immediate = true, property = {"process.label=Email HTML Dump Workflow"})
public class EmailHTMLDumpWorkflow implements WorkflowProcess {

    private static final Logger LOG = LoggerFactory.getLogger(EmailHTMLDumpWorkflow.class);

    @Reference
    private RequestResponseFactory requestResponseFactory;

    @Reference
    private SlingRequestProcessor requestProcessor;

    @Reference
    private EmailHtmlDumpService emailHtmlDumpService;

    public static final String INLINE_STYLES_SELECTOR = "inline-styles";

    @Override
    public void execute(WorkItem workItem, WorkflowSession workflowSession, MetaDataMap metaDataMap) throws WorkflowException {
        String payloadPath = workItem.getWorkflowData().getPayload().toString();
        if (!workItem.getWorkflowData().getPayloadType().equals("JCR_PATH")) {
            LOG.warn("Invalid payload type. Expected JCR_PATH.");
            return;
        }
        Session session = workflowSession.adaptTo(Session.class);
        ResourceResolver resourceResolver = workflowSession.adaptTo(ResourceResolver.class);
        if (session == null || resourceResolver == null) {
            LOG.error("Unable to adapt WorkflowSession to required resources");
            throw new WorkflowException("Cannot obtain session or resource resolver");
        }

        // Step 1: Retrieve the HTML content
        String requestPath = payloadPath + "." + INLINE_STYLES_SELECTOR + ".html";
        LOG.info("Email asset creation requestPath: {}", requestPath);

        try (ByteArrayOutputStream out = new ByteArrayOutputStream()) {  // Try-with-resources for ByteArrayOutputStream
            HttpServletRequest req = requestResponseFactory.createRequest("GET", requestPath); // Create the request
            WCMMode.DISABLED.toRequest(req); // Disable WCM mode
            HttpServletResponse resp = requestResponseFactory.createResponse(out); // Capture the output into ByteArrayOutputStream

            // Process the request using SlingRequestProcessor
            requestProcessor.processRequest(req, resp, resourceResolver);
            String htmlContent = new String (out.toByteArray(), StandardCharsets.UTF_8);
            if (StringUtils.isNotBlank(htmlContent)) {
                htmlContent = htmlContent.replaceAll("(\r?\n+\t?\\s*)", "\n").replace("\n", "");
                LOG.info("Email content generated: {}", htmlContent);

                // Step 2: Store HTML content as an Asset in DAM
                AssetManager assetManager = resourceResolver.adaptTo(AssetManager.class);
                if (assetManager != null) {
                    // Construct a valid DAM path and asset name
                    String assetPath = emailHtmlDumpService.emailHtmlDumpFolderPath() + ConstantUtils.SLASH + payloadPath.substring(payloadPath.lastIndexOf(ConstantUtils.SLASH) + 1) + ".html";
                    // Check if the asset already exists
                    Resource assetResource = resourceResolver.getResource(assetPath);
                    Asset asset = null;
                    if (assetResource != null) {
                        asset = assetResource.adaptTo(Asset.class);
                    }
                    if (asset != null) {
                        LOG.info("Asset already exists at {}", assetPath);
                    } else {
                        try (ByteArrayInputStream inputStream = new ByteArrayInputStream(htmlContent.getBytes(StandardCharsets.UTF_8))) {  // Try-with-resources for ByteArrayInputStream
                            assetManager.createAsset(assetPath, inputStream, "text/html", true);
                            LOG.info("Created new HTML asset at {}", assetPath);
                        }
                    }
                } else {
                    LOG.error("Could not adapt to AssetManager");
                    throw new WorkflowException("Failed to store asset in DAM");
                }
            }
        } catch (IOException | ServletException e) {
            LOG.error("Error during request processing", e);
        } finally {
            session.logout();
        }
    }
}
