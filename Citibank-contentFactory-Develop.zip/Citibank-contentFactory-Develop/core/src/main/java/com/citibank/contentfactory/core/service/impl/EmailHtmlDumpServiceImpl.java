package com.citibank.contentfactory.core.service.impl;

import com.citibank.contentfactory.core.config.EmailHtmlDumpConfig;
import com.citibank.contentfactory.core.service.EmailHtmlDumpService;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.metatype.annotations.Designate;

@Component(service = EmailHtmlDumpService.class, immediate = true)
@Designate(ocd = EmailHtmlDumpConfig.class)
public class EmailHtmlDumpServiceImpl implements EmailHtmlDumpService {

    private EmailHtmlDumpConfig emailHtmlDumpConfig;

    @Activate
    @Modified
    protected final void activate(EmailHtmlDumpConfig emailHtmlDumpConfig){
        this.emailHtmlDumpConfig=emailHtmlDumpConfig;
    }
    @Override
    public String emailHtmlDumpFolderPath() {
        return this.emailHtmlDumpConfig.emailHtmlDumpFolderPath();
    }
}
