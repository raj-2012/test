package com.citibank.contentfactory.core.models;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

/**
 * This class represents a model for individual footer cards.
 * It is used as a child resource within the {FooterModel} class.
 * This model adapts a Sling Resource to provide access to the card's properties.
 */
@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class FooterCards {

    /**
     * The appLink data associated with the application for this footer card.
     * This value is injected from the resource's ValueMap.
     */
    @ValueMapValue
    private String appLink;

    @ValueMapValue
    private String appLinkTitle;

    /**
     * The appIcons data associated with the application for this footer card.
     * This value is injected from the resource's ValueMap.
     */
    @ValueMapValue
    private String appIcons;

    @ValueMapValue
    private String appIconAltText;

    @ValueMapValue
    private String appIconTitle;

    public String getAppLink() {
        return appLink;
    }

    public String getAppIcons() {
        return appIcons;
    }

    public String getAppLinkTitle() {
        return appLinkTitle;
    }

    public String getAppIconAltText() {
        return appIconAltText;
    }

    public String getAppIconTitle() {
        return appIconTitle;
    }
}
