package com.citibank.contentfactory.core.service.impl;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import javax.servlet.http.HttpServletResponse;

import com.citibank.contentfactory.core.service.POSTAPIService;
import com.citibank.contentfactory.core.service.SFMCService;
import com.citibank.contentfactory.core.util.ConstantUtils;
import com.citibank.contentfactory.core.util.HttpClientUtil;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.osgi.services.HttpClientBuilderFactory;
import org.apache.http.util.EntityUtils;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.xss.XSSFilter;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Service Implementation for managing HTTP POST requests
 * and handling SFMC (Salesforce Marketing Cloud) Access Token operations.
 */
@Component(immediate = true, service = POSTAPIService.class)
public class POSTAPIServiceImpl implements POSTAPIService {

    // Logger instance for logging errors and debug information
    private static final Logger logger = LoggerFactory.getLogger(POSTAPIServiceImpl.class);

    // Reference to HttpClientBuilderFactory to build HTTP clients for sending requests
    @Reference
    private HttpClientBuilderFactory clientBuilderFactory;

    // Reference to SFMCService for retrieving SFMC-related URLs
    @Reference
    private SFMCService sfmcService;

    // XSSFilter to sanitize responses for cross-site scripting vulnerabilities
    @Reference
    private XSSFilter xssFilter;

    /**
     * This method sends a POST request to SFMC to retrieve an access token.
     *
     * @param response The Sling HTTP servlet response object.
     * @param payLoad  The JSON payload to be sent in the request body.
     * @return The access token if successful, otherwise an error message.
     */
    @Override
    public String getAccessTokenPOSTAPI(SlingHttpServletResponse response, String payLoad) {
        // Create the StringEntity object to hold the JSON payload
        StringEntity entity = new StringEntity(payLoad, StandardCharsets.UTF_8);

        // Build the HTTP client with custom timeout settings
        CloseableHttpClient client = HttpClientUtil.createHttpClient(clientBuilderFactory, ConstantUtils.SOCKET_TIMEOUT, ConstantUtils.CONNECT_TIMEOUT);

        // Create an HTTP POST request for the access token URL from SFMC service
        HttpPost post = new HttpPost(sfmcService.authUrl());
        post.setHeader("Content-Type", ConstantUtils.APPLICATION_JSON);
        post.setEntity(entity);

        // Execute the request and handle the response
        try (CloseableHttpResponse httpResponse = client.execute(post)) {
            HttpEntity responseEntity = httpResponse.getEntity();

            // Check for successful response (HTTP status 200 or 201)
            if (httpResponse.getStatusLine().getStatusCode() == HttpServletResponse.SC_OK || httpResponse.getStatusLine().getStatusCode() == HttpServletResponse.SC_CREATED) {
                // Parse the response body to retrieve the access token
                String result = EntityUtils.toString(responseEntity, StandardCharsets.UTF_8);
                ObjectMapper objectMapper = new ObjectMapper();
                JsonNode jsonNode = objectMapper.readTree(result);
                return jsonNode.get("access_token").asText();
            } else {
                // Log the failure and return an error message
                logger.error("Failed to retrieve access token, status code: {}", httpResponse.getStatusLine().getStatusCode());
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                return "Failed to retrieve access token, status code";
            }
        } catch (IOException e) {
            // Log any IO exceptions that occur during the request
            logger.error("POST API Service :::::::", e);
            return e.getMessage();
        }
    }

    /**
     * This method sends a POST request to SFMC to create an asset using the provided access token and payload.
     *
     * @param response    The Sling HTTP servlet response object.
     * @param accessToken The access token used for authorization in the request.
     * @param payLoad     The JSON payload to be sent in the request body.
     */
    @Override
    public void getPOSTAPIResponse(SlingHttpServletResponse response, String accessToken, String payLoad) {
        // Build the HTTP client with custom timeout settings
        CloseableHttpClient client = HttpClientUtil.createHttpClient(clientBuilderFactory, ConstantUtils.SOCKET_TIMEOUT, ConstantUtils.CONNECT_TIMEOUT);

        // Create an HTTP POST request for the SFMC asset creation URL
        HttpPost post = new HttpPost(sfmcService.createAssetUrl());
        post.setHeader("Content-Type", ConstantUtils.APPLICATION_JSON);
        post.setHeader("Authorization", "Bearer " + accessToken); // Include access token in the authorization header

        // Set the payload as the request body
        StringEntity entity = new StringEntity(payLoad, StandardCharsets.UTF_8);
        post.setEntity(entity);

        // Execute the request and handle the response
        try (CloseableHttpResponse httpResponse = client.execute(post)) {
            HttpEntity responseEntity = httpResponse.getEntity();
            String result = EntityUtils.toString(responseEntity, StandardCharsets.UTF_8);
            response.setContentType(ConstantUtils.APPLICATION_JSON);


            // Check for successful response (HTTP status 200 or 201)
            if (httpResponse.getStatusLine().getStatusCode() == HttpServletResponse.SC_OK || httpResponse.getStatusLine().getStatusCode() == HttpServletResponse.SC_CREATED) {
                // Parse and sanitize the response body, then write it to the servlet response
                response.setStatus(HttpServletResponse.SC_OK);
                if ("application/json".equals(response.getContentType())) {
                    // Skip XSS filtering for JSON responses
                    response.getWriter().write(result);
                } else {
                    // Apply XSS filter for HTML responses
                    response.getWriter().write(xssFilter.filter(result));
                }
            } else {
                // Log the failure and set an internal server error status
                logger.error("Failed to create asset, status code: {}", httpResponse.getStatusLine().getStatusCode());
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                response.getWriter().write(result);
            }
        } catch (IOException e) {
            // Log any IO exceptions that occur during the request
            logger.error("Error during asset creation: {}", e.getMessage());
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }
    }
}
