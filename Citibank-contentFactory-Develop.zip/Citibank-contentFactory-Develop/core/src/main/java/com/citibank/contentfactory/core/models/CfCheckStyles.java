package com.citibank.contentfactory.core.models;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

/**
 * Sling Model for checking styles in a Content Fragment in AEM.
 * This model adapts both a Resource and a SlingHttpServletRequest
 * and handles optional injections.
 */
@Model(adaptables = {Resource.class, SlingHttpServletRequest.class}, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class CfCheckStyles {

    /**
     * Injects the current Resource being adapted.
     * This is useful for accessing the underlying resource properties.
     */
    @Self
    private Resource resource;

    /**
     * Injects the value of the "cq:styleIds" property.
     * This property represents the style policies applied to the content fragment.
     * If the property is not present, a default empty string array is used.
     */
    @ValueMapValue(name = "cq:styleIds")
    @Default(values = "")
    private String[] styleIds;

    // Value map property for the background color of the content fragment which is choosen from color picker
    @ValueMapValue
    private String bgColor;


    /**
     * Checks whether the "cq:styleIds" property has any non-empty values.
     * 
     * @return true if the styleIds array is not null and contains at least one non-empty value.
     */
    public boolean hasStyleIds() { 
        if (styleIds != null) {
            for (String styleId : styleIds) {
                if (styleId != null && !styleId.trim().isEmpty()) {
                    return true;
                }
            }
        }
        return false;
    }

    // Getter for bgColor.
    public String getBgColor() {
        return bgColor;
    }

    /**
     * Returns the array of style IDs associated with the content fragment.
     * 
     * @return an array of style IDs, or an empty array if no style IDs are set.
     */
    public String[] getStyleIds() {
        return styleIds;
    }
}