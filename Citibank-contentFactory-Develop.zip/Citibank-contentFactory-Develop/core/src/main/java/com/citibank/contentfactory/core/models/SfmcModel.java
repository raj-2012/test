package com.citibank.contentfactory.core.models;

import javax.annotation.PostConstruct;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Exporter;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.day.cq.wcm.api.Page;

// Sling Model for SFMC component
@Model(adaptables = {Resource.class,SlingHttpServletRequest.class},defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
@Exporter(name ="jackson", extensions = "json")
public class SfmcModel {

    // Maps the "jsonPath" property from the JCR resource
    @ValueMapValue
    private String jsonPath;

    // Stores the salesforce folder ID
    @ValueMapValue
    private String folderId;

    // Injects the current page
    @ScriptVariable
    private Page currentPage;

    // Page property set by the workflow to indicate if it is under review
    private Boolean underReview;

    // Page property set by the workflow to indicate if it is under approved
    private Boolean approvedForSFMC;
   
    // Initializes the model after construction
    @PostConstruct
    private void init() {
        // Retrieves the "underReview" property from the current page
        underReview = currentPage.getProperties().get("underReview", Boolean.class);
        // Retrieves the "approvedForSFMC" property from the current page
        approvedForSFMC = currentPage.getProperties().get("approvedForSFMC",Boolean.class);
    }

    // Returns the value of the jsonPath property
    public String getJsonPath() {
        return jsonPath;
    }

    // Returns the value of the folderId property
    public String getFolderId() {
        return folderId;
    }

    // Returns the current page
    public Page getCurrentPage() {
        return currentPage;
    }

    // Returns the underReview status
    public Boolean getUnderReview() {
        return underReview;
    }

    // Returns the underReview status
    public Boolean getApprovedForSFMC(){
        return approvedForSFMC;
    }
}

