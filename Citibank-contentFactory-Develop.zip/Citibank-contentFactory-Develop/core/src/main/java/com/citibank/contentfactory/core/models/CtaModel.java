package com.citibank.contentfactory.core.models;

import com.adobe.cq.wcm.core.components.models.Button;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.models.annotations.via.ResourceSuperType;

/**
 * This Sling Model adapts the SlingHttpServletRequest and is mapped to a custom Button component.
 * It implements the Button interface to inherit button behavior from a resource supertype.
 */
@Model(
        adaptables = SlingHttpServletRequest.class, // The model adapts to the Sling HTTP request.
        resourceType = CtaModel.RESOURCE_TYPE, // Binds this model to the specified component's resource type.
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL // Marks all fields as optional by default.
)
public class CtaModel implements Button {

    // The resource type that this model is bound to, specified in the ui.apps component path.
    static final String RESOURCE_TYPE = "/apps/citibank-cf/components/buttonemail";

    // Adapts the button functionality from a resource supertype.
    @Self
    @Via(type = ResourceSuperType.class)
    private Button button;

    // Value map property for the button type (e.g., primary, secondary).
    @ValueMapValue
    private String type;

    // Value map property for the button shape (e.g., rounded or not).
    @ValueMapValue
    private String rounded;

    // Value map property for the link target (e.g., _blank, _self).
    @ValueMapValue
    private String linkTarget;

    // Value map property for the link URL the button should navigate to.
    @ValueMapValue
    private String linkURL;

    // Value map property for the link URL Title the button should navigate to.
    @ValueMapValue
    private String linkUrlTitle;

    // Value map property for the button title.
    @ValueMapValue
    private String title;

    // Value map property for whether to show an image on the button.
    @ValueMapValue
    private String showImage;

    // Value map property for the image file reference (used if showImage is true).
    @ValueMapValue
    private String fileReference;

    // Value map property for the image file Alt text (used if showImage is true).
    @ValueMapValue
    private String fileAltText;

    // Value map property for the image file title (used if showImage is true).
    @ValueMapValue
    private String fileTitle;

    // Value map property for specifying the button width.
    @ValueMapValue
    private String width;

    // Getter for button type.
    public String getType() {
        return type;
    }

    // Getter for button rounded shape property.
    public String getRounded() {
        return rounded;
    }

    // Getter for link target (e.g., open in new tab).
    public String getLinkTarget() {
        return linkTarget;
    }

    // Getter for link URL.
    public String getLinkURL() {
        return linkURL;
    }

    // Getter for the button title.
    public String getTitle() {
        return title;
    }

    // Getter for the flag indicating if an image should be shown.
    public String getShowImage() {
        return showImage;
    }

    // Getter for the image file reference.
    public String getFileReference() {
        return fileReference;
    }

    // Getter for button width.
    public String getWidth() {
        return width;
    }

    // Overridden method to get the button text, inheriting from the supertype.
    @Override
    public String getText() {
        return button.getText();
    }

    // Overridden method to get the button ID, inheriting from the supertype.
    @Override
    public String getId() {
        return button.getId();
    }

    // Overridden method to get the accessibility label for the button, inheriting from the supertype.
    @Override
    public String getAccessibilityLabel() {
        return button.getAccessibilityLabel();
    }

    // Overridden method to get the button icon, inheriting from the supertype.
    @Override
    public String getIcon() {
        return button.getIcon();
    }
    
    // Getter for link Url Title.
    public String getLinkUrlTitle() {
        return linkUrlTitle;
    }

    // Getter for file Alt text.
    public String getFileAltText() {
        return fileAltText;
    }

    // Getter for file Title.
    public String getFileTitle() {
        return fileTitle;
    }
}