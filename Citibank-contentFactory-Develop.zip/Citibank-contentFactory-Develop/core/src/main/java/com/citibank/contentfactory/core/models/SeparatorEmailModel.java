package com.citibank.contentfactory.core.models;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

/**
 * This Sling Model adapts to the Resource and represents the configuration for a separator component
 * used in emails. It allows authors to define the height of the separator.
 */
@Model(
        adaptables = Resource.class, // The model adapts to Sling Resource, making it usable within resource contexts.
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL // Marks all fields as optional for injection.
)
public class SeparatorEmailModel {

    // Injects the 'height' property from the ValueMap of the resource.
    @ValueMapValue
    private String height;

    public String getHeight() {
        return height;
    }
}


