package com.citibank.contentfactory.core.config;

import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;

//These configurations used for the getting the Email Html Dump Folder Path
@ObjectClassDefinition(name = "Email Html Dump Folder Path")
public @interface EmailHtmlDumpConfig {
    @AttributeDefinition(name = "Email Html Dump Folder Path", description = "Select Folder Path from Dam")
    String emailHtmlDumpFolderPath() ;
}
