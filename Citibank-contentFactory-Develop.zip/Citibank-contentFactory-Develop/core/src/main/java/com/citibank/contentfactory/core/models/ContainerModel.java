package com.citibank.contentfactory.core.models;

import java.util.List;
import org.apache.sling.api.SlingHttpServletRequest;
import com.adobe.cq.email.core.components.models.Container;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.models.annotations.via.ResourceSuperType;

@Model(
        adaptables = SlingHttpServletRequest.class,
        resourceType = ContainerModel.RESOURCE_TYPE,
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
public class ContainerModel implements Container {

    // points to the component resource path in ui.apps
    static final String RESOURCE_TYPE = "/apps/citibank-cf/components/email/container";

    // With sling inheritance (sling:resourceSuperType) we can adapt the current resource to the Container class
    // this allows us to re-use the functionality of the Container class, without having to implement it ourself
    @Self
    @Via(type = ResourceSuperType.class)
    private Container container;

    // The name of the block for SFMC configuration
    @ValueMapValue
    private String blockName;

    // The name of the slot for SFMC configuration
    @ValueMapValue
    private String slotName;

    // The type of the container for SFMC configuration
    @ValueMapValue
    private String blockSlotType;

    // The message associated with the slot
    @ValueMapValue
    private String slotMessage;

    // background color for the container
    @ValueMapValue
    private String backgroundColor;

    // Getter methods to retrieve the injected properties.

    public String getBlockName() {
        return blockName;
    }

    public String getSlotName() {
        return slotName;
    }

    public String getBlockSlotType() {
        return blockSlotType;
    }

    public String getSlotMessage() {
        return slotMessage;
    }

    public String getBackgroundColor() {
        return backgroundColor;
    }

    /* overriding existing method from the implemented core component */
    @Override
    public List getColumns() {
        return container.getColumns();
    }

}
