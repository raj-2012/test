package com.citibank.contentfactory.core.service;

import org.apache.sling.api.SlingHttpServletResponse;

public interface POSTAPIService {

    String getAccessTokenPOSTAPI(SlingHttpServletResponse response, String payLoad);

    void getPOSTAPIResponse(SlingHttpServletResponse response, String accessToken, String payLoad);
}