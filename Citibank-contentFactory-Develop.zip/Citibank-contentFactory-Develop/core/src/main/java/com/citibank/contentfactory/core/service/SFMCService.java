package com.citibank.contentfactory.core.service;

//This service class contains SFMC Configurations
public interface SFMCService {
    String authUrl();
    String createAssetUrl();
    String clientId();
    String clientSecret();
    String accountId();
    String assetIdURL();
}