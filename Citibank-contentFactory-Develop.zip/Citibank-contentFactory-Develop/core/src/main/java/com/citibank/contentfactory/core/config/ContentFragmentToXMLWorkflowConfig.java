package com.citibank.contentfactory.core.config;

import org.osgi.annotation.versioning.ProviderType;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;

@ObjectClassDefinition(name = "Content Fragment to XML Workflow Configuration", description = "Configuration for Content Fragment to XML Workflow Process")
@ProviderType
public @interface ContentFragmentToXMLWorkflowConfig {

    @AttributeDefinition(
        name = "Target Folder Path",
        description = "Specify the target folder path where the XML files should be saved."
    )
    String targetFolderPath() default "/content/dam/projects/citi-xml-contentfragments";
}
