package com.citibank.contentfactory.core.models;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

// Define the Sling Model for the ButtonGroupComponent
@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class ButtonGroupComponent {

    // Maps the "bgColor" property from the JCR resource
    @ValueMapValue
    private String bgColor;

    // Maps the "continuousFlag" property from the JCR resource
    @ValueMapValue
    private String continuousFlag;

    // Maps the "buttonsCard" multifield from the JCR resource as a list of resources
    @ChildResource(name = "buttonsCard")
    private Resource buttonsCard;

    // Returns the value of the bgColor property
    public String getBgColor() {
        return bgColor;
    }

    // Returns the value of the continuousFlag property
    public String getContinuousFlag() {
        return continuousFlag;
    }

    // Retrieves a list of Button items from the buttonsCard multifield
    public List<ButtonData> getButtonsCard() {
        List<ButtonData> buttons = new ArrayList<>();

        if (buttonsCard != null) {
            for (Resource buttonResource : buttonsCard.getChildren()) {
                String link = Optional.ofNullable(buttonResource.getValueMap().get("link", String.class)).orElse("");
                String text = Optional.ofNullable(buttonResource.getValueMap().get("text", String.class)).orElse("");
                String title = Optional.ofNullable(buttonResource.getValueMap().get("title", String.class)).orElse("");

                buttons.add(new ButtonData(link, text, title));
            }
        }
        return buttons;
    }

    // Inner class to represent button data without creating a separate model class
    public static class ButtonData {
        private final String link;
        private final String text;
        private final String title;

        public ButtonData(String link, String text, String title) {
            this.link = link;
            this.text = text;
            this.title = title;
        }

        public String getLink() {
            return link;
        }

        public String getText() {
            return text;
        }

        public String getTitle() {
            return title;
        }
    }
}
