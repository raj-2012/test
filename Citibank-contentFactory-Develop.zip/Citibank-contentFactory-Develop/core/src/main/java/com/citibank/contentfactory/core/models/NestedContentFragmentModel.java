package com.citibank.contentfactory.core.models;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import com.adobe.cq.dam.cfm.ContentElement;
import com.adobe.cq.dam.cfm.ContentFragment;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.RequestAttribute;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * A Sling Model that processes nested content fragments based on references.
 * It collects content elements from content fragments and organizes them
 * into a list of maps for further use.
 */
@Model(
        adaptables = SlingHttpServletRequest.class,
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
public class NestedContentFragmentModel {

    private static final Logger LOG = LoggerFactory.getLogger(NestedContentFragmentModel.class);

    
    /**
     * The design configuration for the content fragment.
     * This value is injected from the resource's properties.
     */
    @ValueMapValue
    private String cfDesign;

    /**
     * The Sling resource associated with the request.
     */
    @SlingObject
    private Resource resource;

    /**
     * Content fragment reference(s) passed as a request attribute.
     * This can hold multiple references, separated by commas.
     */
    @RequestAttribute
    private String cfReference;

    /**
     * A list to store the elements for each processed content fragment.
     * Each content fragment's elements are stored as a map where
     * the key is the element name and the value is the content.
     */
    private final List<Map<String, String>> fragmentElementsList = new ArrayList<>();

    /**
     * Initializes the model after the object is created.
     * Processes the content fragment references and collects their elements.
     */
    @PostConstruct
    protected void init() {
        if (StringUtils.isNotBlank(cfReference)) {
            handleCfReferences();
        } else {
            LOG.warn("Content fragment reference is blank or null.");
        }
    }

    /**
     * Splits the content fragment references and processes each one.
     * It uses the resource resolver to resolve the references into actual resources.
     */
    private void handleCfReferences() {
        String[] cfReferences = cfReference.split(",");
        ResourceResolver resolver = getResourceResolver();

        if (resolver != null) {
            processCfReferences(cfReferences, resolver);
        } else {
            LOG.warn("Resource resolver is null. Cannot resolve content fragment references.");
        }
    }

    /**
     * Retrieves the resource resolver from the current resource.
     *
     * @return ResourceResolver object if available, null otherwise.
     */
    private ResourceResolver getResourceResolver() {
        return resource != null ? resource.getResourceResolver() : null;
    }

    /**
     * Iterates through the array of content fragment references,
     * resolves them, and processes each one.
     *
     * @param cfReferences Array of content fragment references.
     * @param resolver     The resource resolver used to resolve content fragment resources.
     */
    private void processCfReferences(String[] cfReferences, ResourceResolver resolver) {
        for (String ref : cfReferences) {
            ref = ref.trim();
            if (StringUtils.isNotBlank(ref)) {
                processSingleReference(ref, resolver);
            }
        }
    }

    /**
     * Processes a single content fragment reference by resolving it
     * and collecting its elements if it can be adapted to a ContentFragment.
     *
     * @param ref      The reference path to the content fragment.
     * @param resolver The resource resolver used to retrieve the resource.
     */
    private void processSingleReference(String ref, ResourceResolver resolver) {
        try {
            Resource fragmentResource = resolver.getResource(ref);
            if (fragmentResource != null) {
                processFragmentResource(fragmentResource);
            } else {
                LOG.warn("Could not find resource for reference: {}", ref);
            }
        } catch (Exception e) {
            LOG.error("Error processing content fragment reference: {}", ref, e);
        }
    }

    /**
     * Adapts the resolved resource to a ContentFragment and collects its elements.
     *
     * @param fragmentResource The resolved content fragment resource.
     */
    private void processFragmentResource(Resource fragmentResource) {
        ContentFragment contentFragment = fragmentResource.adaptTo(ContentFragment.class);
        if (contentFragment != null) {
            collectFragmentElements(contentFragment);
        } else {
            LOG.warn("Could not adapt resource to ContentFragment: {}", fragmentResource.getPath());
        }
    }

    /**
     * Iterates through the content elements of the given content fragment
     * and stores them in a map. Adds the map to the fragmentElementsList.
     *
     * @param contentFragment The content fragment from which to extract elements.
     */
    private void collectFragmentElements(ContentFragment contentFragment) {
        Map<String, String> fragmentElements = new HashMap<>();
        Iterator<ContentElement> contentElements = contentFragment.getElements();

        while (contentElements.hasNext()) {
            addContentElementToMap(contentElements.next(), fragmentElements);
        }

        if (!fragmentElements.isEmpty()) {
            fragmentElementsList.add(fragmentElements);
        }
    }

    /**
     * Adds a content element's name and content to the map if valid.
     *
     * @param element          The content element to add.
     * @param fragmentElements The map in which to store the element's name and content.
     */
    private void addContentElementToMap(ContentElement element, Map<String, String> fragmentElements) {
        String name = element.getName();
        String value = element.getContent();

        if (StringUtils.isNotBlank(name) && value != null) {
            fragmentElements.put(name, value);
        } else {
            LOG.warn("Content element name or value is null/empty. Skipping element.");
        }
    }

    /**
     * Returns the list of collected content fragment elements.
     *
     * @return A list of maps where each map contains the elements of a content fragment.
     */
    public List<Map<String, String>> getFragmentElementsList() {
        return fragmentElementsList;
    }

    /**
     * Returns the design configuration of the content fragment.
     *
     * @return The content fragment design (cfDesign).
     */
    public String getCfDesign() {
        return cfDesign;
    }
}