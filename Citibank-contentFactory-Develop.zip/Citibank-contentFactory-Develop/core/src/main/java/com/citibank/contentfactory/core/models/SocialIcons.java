package com.citibank.contentfactory.core.models;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

/**
 * This class represents a model for social media icons.
 * It is used as a child resource within the {FooterModel} class.
 * This model adapts a Sling Resource to provide access to the social media icons and their associated links.
 */
@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class SocialIcons {

    /**
     * The socialMediaLink associated with the first social media icon.
     * This value is injected from the resource's ValueMap.
     */
    @ValueMapValue
    private String socialMediaLink;

    @ValueMapValue
    private String socialMediaLinkTitle;

    /**
     * The icon associated with the first social media link.
     * This value is injected from the resource's ValueMap.
     */
    @ValueMapValue
    private String icons;

    @ValueMapValue
    private String iconAltText;

    @ValueMapValue
    private String iconTitle;

    public String getSocialMediaLink() {
        return socialMediaLink;
    }

    public String getIcons() {
        return icons;
    }

    public String getSocialMediaLinkTitle() {
        return socialMediaLinkTitle;
    }

    public String getIconAltText() {
        return iconAltText;
    }

    public String getIconTitle() {
        return iconTitle;
    }
}
