package com.citibank.contentfactory.core.service.impl;

import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.metatype.annotations.Designate;

import com.citibank.contentfactory.core.config.SFMCConfig;
import com.citibank.contentfactory.core.service.SFMCService;

//This Service Impl indicates in getting the SFMC Configurations
@Component(service = SFMCService.class, immediate = true)
@Designate(ocd = SFMCConfig.class)
public class SFMCServiceImpl implements SFMCService {

    private SFMCConfig sfmcConfig;

    @Activate
    @Modified
    protected final void activate(SFMCConfig sfmcConfig) {
        this.sfmcConfig = sfmcConfig;
    }

    @Override
    public String authUrl() {
        return this.sfmcConfig.authUrl();
    }

    @Override
    public String createAssetUrl() {
        return this.sfmcConfig.createAssetUrl();
    }

    @Override
    public String clientId() {
        return this.sfmcConfig.clientId();
    }

    @Override
    public String clientSecret() {
        return this.sfmcConfig.clientSecret();
    }

    @Override
    public String accountId() { return this.sfmcConfig.accountId();    }

    @Override
    public String assetIdURL() {
        return this.sfmcConfig.assetIdURL();
    }
}