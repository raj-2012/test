package com.citibank.contentfactory.core.models;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

// Sling Model for PreHeader component
@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class PreHeaderModel {

    // Maps the "logo" property from the JCR resource
    @ValueMapValue
    private String logo;

    // Maps the "text" property from the JCR resource
    @ValueMapValue
    private String text;

     // Maps the "altText" property from the JCR resource
    @ValueMapValue
    private String altText;
    
     // Maps the "title" property from the JCR resource
    @ValueMapValue
    private String title;

    // Maps the "viewInBrowserText" property from the JCR resource
    @ValueMapValue
    private String viewInBrowserText;

     // Maps the "BrowserTitle" property from the JCR resource
    @ValueMapValue
    private String browserTitle;

    // Maps the "name" property from the JCR resource
    @ValueMapValue
    private String name;

    // Maps the "cardmemberSinceText" property from the JCR resource
    @ValueMapValue
    private String cardMemberSinceText;

    // Maps the "cardmemberSince" property from the JCR resource
    @ValueMapValue
    private String cardMemberSince;

    // Maps the "lockIcon" property from the JCR resource
    @ValueMapValue
    private String lockIcon;

     // Maps the "lockIconAltText" property from the JCR resource
    @ValueMapValue
    private String lockIconAltText;

     // Maps the "lockIconTitle" property from the JCR resource
    @ValueMapValue
    private String lockIconTitle;

    // Maps the "accountEndingIn" property from the JCR resource
    @ValueMapValue
    private String accountEndingIn;

    // Maps the "accountNumber" property from the JCR resource
    @ValueMapValue
    private String accountNumber;

    // Maps the "cardImage" property from the JCR resource
    @ValueMapValue
    private String cardImage;

    // Maps the "cardImageAltText" property from the JCR resource
    @ValueMapValue
    private String cardImageAltText;

    // Maps the "cardImageTitle" property from the JCR resource
    @ValueMapValue
    private String cardImageTitle;

    // Maps the "valuedCustomer" property from the JCR resource
    @ValueMapValue
    private String valuedCustomer;

    // Maps the "color" property from the JCR resource
    @ValueMapValue
    private String color;

    // Returns the value of the valuedCustomer property
    public String getValuedCustomer() {
        return valuedCustomer;
    }

    // Returns the value of the cardmemberSinceText property
    public String getCardMemberSinceText() {
        return cardMemberSinceText;
    }

    // Returns the value of the cardmemberSince property
    public String getCardMemberSince() {
        return cardMemberSince;
    }

    // Returns the value of the text property
    public String getText() {
        return text;
    }

    // Returns the value of the name property
    public String getName() {
        return name;
    }

    // Returns the value of the accountEndingIn property
    public String getAccountEndingIn() {
        return accountEndingIn;
    }

    // Returns the value of the accountNumber property
    public String getAccountNumber() {
        return accountNumber;
    }

    // Returns the value of the cardImage property
    public String getCardImage() {
        return cardImage;
    }

    // Returns the value of the color property
    public String getColor() {
        return color;
    }

    // Returns the value of the logo property
    public String getLogo() {
        return logo;
    }

    // Returns the value of the lockIcon property
    public String getLockIcon() {
        return lockIcon;
    }

    // Returns the value of the viewInBrowserText property
    public String getViewInBrowserText() {
        return viewInBrowserText;
    }

    // Returns the value of the altText property
    public String getAltText() {
        return altText;
    }

    // Returns the value of the title property
    public String getTitle() {
        return title;
    }

    // Returns the value of the BrowserTitle property
    public String getBrowserTitle() {
        return browserTitle;
    }

    // Returns the value of the lockIconAltText property
    public String getLockIconAltText() {
        return lockIconAltText;
    }

    // Returns the value of the lockIconTitle property      
    public String getLockIconTitle() {
        return lockIconTitle;
    }

    // Returns the value of the cardImageAltText property 
    public String getCardImageAltText() {
        return cardImageAltText;
    }

    // Returns the value of the cardImageTitle property 
    public String getCardImageTitle() {
        return cardImageTitle;
    }
}

