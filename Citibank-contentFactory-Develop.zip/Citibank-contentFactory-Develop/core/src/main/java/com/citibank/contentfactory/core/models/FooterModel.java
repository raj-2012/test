package com.citibank.contentfactory.core.models;

import java.util.List;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;

/**
 * This class represents a model for the footer section of the content.
 * It adapts a Sling Resource to this model and provides lists of child resources.
 */
@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class FooterModel {

    /**
     * List of FooterCards child resources.
     * This represents the footer cards to be displayed in the footer.
     */
    @ChildResource
    private List<FooterCards> footerCard;

    /**
     * List of SocialIcons child resources.
     * This represents the social media icons to be displayed in the footer.
     */
    @ChildResource
    private List<SocialIcons> socialMediaIcons;

    public List<FooterCards> getFooterCard() {
        return footerCard;
    }

    public List<SocialIcons> getSocialMediaIcons() {
        return socialMediaIcons;
    }
}
