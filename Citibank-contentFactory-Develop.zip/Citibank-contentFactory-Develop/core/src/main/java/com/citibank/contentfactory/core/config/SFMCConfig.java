package com.citibank.contentfactory.core.config;

import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;

//These configurations used for the getting the SFMC Access Token and for creating the SFMC Assets
@ObjectClassDefinition(name = "SFMC Configuration")
public @interface SFMCConfig {

    @AttributeDefinition(name = "SFMC Auth URL", description = "URL for SFMC authentication")
    String authUrl() default "https://.auth.marketingcloudapis.com/v2/token";

    @AttributeDefinition(name = "SFMC Create Asset URL", description = "URL for creating SFMC asset")
    String createAssetUrl() default "https://.rest.marketingcloudapis.com/asset/v1/content/assets";

    @AttributeDefinition(name = "Client ID", description = "Client ID for SFMC")
    String clientId();

    @AttributeDefinition(name = "Client Secret", description = "Client Secret for SFMC")
    String clientSecret();

    @AttributeDefinition(name = "Account ID", description = "Account ID for SFMC")
    String accountId();

    @AttributeDefinition(name = "Assets ID URL SMFC", description = "content by Assets ID from SMFC")
    String assetIdURL();
}