package com.citibank.contentfactory.core.workflows;

import com.citibank.contentfactory.core.util.ConstantUtils;
import org.apache.sling.api.resource.PersistenceException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ModifiableValueMap;
import org.osgi.service.component.annotations.Component;
import com.adobe.granite.workflow.WorkflowSession;
import com.adobe.granite.workflow.exec.WorkItem;
import com.adobe.granite.workflow.exec.WorkflowProcess;
import com.adobe.granite.workflow.metadata.MetaDataMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component(
        service = WorkflowProcess.class,
        property = {"process.label=Set Approved For SFMC Property Process"}
)
/**
 * This class defines a custom AEM workflow process that:
 * 1. Sets the `underReview` property to `false` if it is currently `true`.
 * 2. Sets the `approvedForSFMC` property to `true`.
 * 3. Sets the `emailApprovedBy` property using the value from `cq:lastModifiedBy`.
 */
public class SetApprovedForSFMCPropertyProcess implements WorkflowProcess {

    // Logger to log errors or debugging information during workflow execution
    private static final Logger LOG = LoggerFactory.getLogger(SetApprovedForSFMCPropertyProcess.class);

    /**
     * This method is invoked when the workflow process is executed.
     * It retrieves the page from the workflow payload, modifies the `underReview` property,
     * sets the `approvedForSFMC` and `emailApprovedBy` properties, and saves the changes.
     *
     * @param workItem        The current workflow item, containing data such as payload.
     * @param workflowSession The session for interacting with workflow-related resources.
     * @param metaDataMap     Additional metadata or arguments for the workflow step.
     */
    @Override
    public void execute(WorkItem workItem, WorkflowSession workflowSession, MetaDataMap metaDataMap) {

        // Get the page path from the workflow payload
        String pagePath = workItem.getWorkflowData().getPayload().toString();
        // Adapt the workflow session to get the ResourceResolver, which is used to access JCR resources
        ResourceResolver resolver = workflowSession.adaptTo(ResourceResolver.class);
        // Retrieve the `jcr:content` resource of the page
        Resource pageResource = resolver.getResource(pagePath + ConstantUtils.SLASH+ConstantUtils.JCR_CONTENT);
        // If the page's `jcr:content` node is found, attempt to modify its properties
        if (pageResource != null) {
            // Adapt the resource to ModifiableValueMap to allow changes to the properties
            ModifiableValueMap properties = pageResource.adaptTo(ModifiableValueMap.class);
            // Check if `underReview` is true, and if so, set it to false
            Boolean underReview = properties.get("underReview", Boolean.class);
            if (underReview != null && underReview) {
                properties.put("underReview", false);
            }
            // Set the `approvedForSFMC` property to true
            properties.put("approvedForSFMC", true);
            try {
                // Commit the changes to persist them in the JCR
                resolver.commit();
                LOG.info("Changes committed successfully for page: {}", pagePath);
            } catch (PersistenceException e) {
                // Log an error if there is an issue while committing the changes
                LOG.error("Error committing changes to the JCR for page: {}", pagePath, e);
            }
        } else {
            // Log an error if the `jcr:content` node is not found
            LOG.error("Page resource not found for path: {}", pagePath);
        }
    }
}
