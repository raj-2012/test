package com.citibank.contentfactory.core.workflows;

import java.io.IOException;
import javax.xml.stream.XMLStreamException;
import javax.jcr.RepositoryException;
import com.adobe.granite.workflow.WorkflowException;
import com.adobe.granite.workflow.WorkflowSession;
import com.adobe.granite.workflow.exec.WorkItem;
import com.adobe.granite.workflow.metadata.MetaDataMap;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.PersistenceException;

/**
 * Interface for processing Content Fragment to XML Workflow
 */
public interface ContentFragmentToXMLWorkflow {

    /**
     * Executes the workflow process.
     * 
     * @param workItem the WorkItem of the workflow
     * @param workflowSession the session for executing workflow operations
     * @param metaDataMap a map of workflow metadata
     * @throws WorkflowException if there is an issue with the workflow process
     */
    void execute(WorkItem workItem, WorkflowSession workflowSession, MetaDataMap metaDataMap) throws WorkflowException;

    /**
     * Generates XML from a content fragment variation resource.
     * 
     * @param contentFragmentVariation the content fragment variation resource
     * @return the generated XML string
     * @throws XMLStreamException if there is an error with XML generation
     */
    String generateXMLFromContentFragment(Resource contentFragmentVariation) throws XMLStreamException, PersistenceException;

    /**
     * Processes variations of content fragment and saves the XML to DAM.
     * 
     * @param resourceResolver the ResourceResolver for accessing resources
     * @param variationsNode the variations node resource
     * @param payloadPath the payload path of the content fragment
     * @throws PersistenceException if there is a persistence error
     * @throws XMLStreamException if there is an error with XML generation
     * @throws IOException if there is an IO error
     * @throws RepositoryException if there is a repository error
     */
    void processVariations(ResourceResolver resourceResolver, Resource variationsNode, String payloadPath)
            throws PersistenceException, XMLStreamException, IOException, RepositoryException;

    /**
     * Saves the generated XML to the DAM at the specified path.
     * 
     * @param resourceResolver the ResourceResolver for accessing resources
     * @param xmlData the XML data to be saved
     * @param payloadPath the payload path of the content fragment
     * @param variationName the variation name
     * @throws PersistenceException if there is a persistence error
     * @throws RepositoryException if there is a repository error
     */
    void saveXMLToDAM(ResourceResolver resourceResolver, String xmlData, String payloadPath, String variationName)
            throws PersistenceException, RepositoryException;

}
