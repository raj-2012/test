package com.citibank.contentfactory.core.models;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;


/**
 * This class represents an individual icon card within the hero frame.
 * It adapts a Sling Resource to this model and provides access to the properties of the icon card.
 */

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class IconCard {

    // Path to the right-side icon for the card.
    @ValueMapValue
    private String rightSideIcon;

    // Text displayed on the icon.
    @ValueMapValue
    private String textOnIcon;

    // Width of the icon.
    @ValueMapValue
    private Integer width;

    // Height of the icon.
    @ValueMapValue
    private Integer height;

    // Path to the right-side icon alt text for the card.
    @ValueMapValue
    private String iconAltText;

    // Path to the right-side icon Title for the card.
    @ValueMapValue
    private String iconTitle;

    // Getter methods to retrieve the properties of the icon card.

    public String getIconAltText() {
        return iconAltText;
    }

    public String getIconTitle() {
        return iconTitle;
    }

    public String getRightSideIcon() {
        return rightSideIcon;
    }


    public String getTextOnIcon() {
        return textOnIcon;
    }

    public Integer getWidth() {
        return width;
    }

    public Integer getHeight() {
        return height;
    }
}
