package com.citibank.contentfactory.core.service;

import org.apache.sling.api.SlingHttpServletResponse;

public interface GETApiService {
    void getGETAPIResponse(SlingHttpServletResponse response, String accessToken, String payLoad);
}
