package com.citibank.contentfactory.core.workflows;

import com.citibank.contentfactory.core.util.ConstantUtils;
import org.apache.sling.api.resource.PersistenceException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ModifiableValueMap;
import org.osgi.service.component.annotations.Component;
import com.adobe.granite.workflow.WorkflowSession;
import com.adobe.granite.workflow.exec.WorkItem;
import com.adobe.granite.workflow.exec.WorkflowProcess;
import com.adobe.granite.workflow.metadata.MetaDataMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * This class implements a custom AEM workflow process that sets a page's "underReview"
 * property to true when it is executed. The process is designed to be triggered
 * as part of a workflow model in AEM.
 */
@Component(
        service = WorkflowProcess.class,
        property = {"process.label=Set Under Review Property Process"}
)
public class SetUnderReviewPropertyProcess implements WorkflowProcess {

    // Logger instance to log errors and process-related information.
    private static final Logger LOG = LoggerFactory.getLogger(SetUnderReviewPropertyProcess.class);

    /**
     * The method that is executed when the workflow process is triggered.
     * It retrieves the payload (the path of the page being processed),
     * and sets the "underReview" property to true on the page's jcr:content node.
     *
     * @param workItem The work item containing the workflow data.
     * @param workflowSession The workflow session used to adapt to a ResourceResolver.
     * @param metaDataMap Metadata about the workflow, which can contain additional configurations.
     */
    @Override
    public void execute(WorkItem workItem, WorkflowSession workflowSession, MetaDataMap metaDataMap) {

        // Get the page path from the workflow payload (assumed to be a page path).
        String pagePath = workItem.getWorkflowData().getPayload().toString();
        // Obtain the ResourceResolver from the WorkflowSession to access AEM resources.
        ResourceResolver resolver = workflowSession.adaptTo(ResourceResolver.class);
        // Retrieve the jcr:content node of the page.
        Resource pageResource = resolver.getResource(pagePath + ConstantUtils.SLASH+ConstantUtils.JCR_CONTENT);
        // If the jcr:content node is found, proceed to modify its properties.
        if (pageResource != null) {
            // Adapt the resource to a ModifiableValueMap to modify the properties.
            ModifiableValueMap properties = pageResource.adaptTo(ModifiableValueMap.class);
            // Set the "underReview" property to true.
            properties.put("underReview", true);
            try {
                // Commit the changes to the JCR repository.
                resolver.commit();
            } catch (PersistenceException e) {
                // Log an error if there is an issue with committing the changes.
                LOG.error("Error during request processing", e);
            }
        }
    }
}
