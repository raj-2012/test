package com.citibank.contentfactory.core.service.impl;

import com.citibank.contentfactory.core.service.GETApiService;
import com.citibank.contentfactory.core.service.SFMCService;
import com.citibank.contentfactory.core.util.ConstantUtils;
import com.citibank.contentfactory.core.util.HttpClientUtil;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.osgi.services.HttpClientBuilderFactory;
import org.apache.http.util.EntityUtils;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.xss.XSSFilter;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

@Component(immediate = true, service = GETApiService.class)
public class GETApiServiceImpl implements GETApiService {

    // Logger instance for logging errors and debug information
    private static final Logger logger = LoggerFactory.getLogger(GETApiServiceImpl.class);

    @Reference
    private HttpClientBuilderFactory clientBuilderFactory;

    // Reference to SFMCService for retrieving SFMC-related URLs
    @Reference
    private SFMCService sfmcService;

    // XSSFilter to sanitize responses for cross-site scripting vulnerabilities
    @Reference
    private XSSFilter xssFilter;

    @Override
    public void getGETAPIResponse(SlingHttpServletResponse response, String accessToken, String assetId) {

        // Build the HTTP client with custom timeout settings
        CloseableHttpClient client = HttpClientUtil.createHttpClient(clientBuilderFactory, ConstantUtils.SOCKET_TIMEOUT, ConstantUtils.CONNECT_TIMEOUT);

        String endPointApi = sfmcService.assetIdURL() + assetId;
        // Create an HTTP POST request for the SFMC asset creation URL
        HttpGet get = new HttpGet(endPointApi);
        get.setHeader("Content-Type", ConstantUtils.APPLICATION_JSON);
        get.setHeader("Authorization", "Bearer " + accessToken);

        // Execute the request and handle the response
        try (CloseableHttpResponse httpResponse = client.execute(get)) {
            HttpEntity responseEntity = httpResponse.getEntity();
            String result = EntityUtils.toString(responseEntity, StandardCharsets.UTF_8);
            response.setContentType(ConstantUtils.APPLICATION_JSON);


            // Check for successful response (HTTP status 200 or 201)
            if (httpResponse.getStatusLine().getStatusCode() == HttpServletResponse.SC_OK || httpResponse.getStatusLine().getStatusCode() == HttpServletResponse.SC_CREATED) {
                // Parse and sanitize the response body, then write it to the servlet response
                response.setStatus(HttpServletResponse.SC_OK);
                if ("application/json".equals(response.getContentType())) {
                    // Skip XSS filtering for JSON responses
                    response.getWriter().write(result);
                } else {
                    // Apply XSS filter for HTML responses
                    response.getWriter().write(xssFilter.filter(result));
                }
            } else {
                // Log the failure and set an internal server error status
                logger.error("Failed to create asset, status code: {}", httpResponse.getStatusLine().getStatusCode());
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                response.getWriter().write(result);
            }
        } catch (IOException e) {
            // Log any IO exceptions that occur during the request
            logger.error("Error during asset creation: {}", e.getMessage());
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }
    }
    }
