package com.citibank.contentfactory.core.util;

/**
 * This file will contain constants
 */
public class ConstantUtils {

    private ConstantUtils() {
        throw new IllegalStateException("ConstantUtils class");
    }

    public static final String DATAWRITER = "datawriter";
    public static final String APPLICATION_XML = "application/xml" ;
    public static final String JCR_CONTENT = "jcr:content";
    public static final String CONTENT_DAM ="/content/dam";
    public static final String JCR_PRIMARY_TYPE = "jcr:primaryType";
    public static final String JCR_MIXIN_TYPES = "jcr:mixinTypes";
    public static final String CQ_LAST_MODIFIED = "cq:lastModified";
    public static final String CQ_LAST_MODIFIED_BY = "cq:lastModifiedBy";
    public static final String JCR_CREATED = "jcr:created";
    public static final String JCR_CREATED_BY = "jcr:createdBy";

    // Other constants you may already have
    public static final String JCR_TITLE = "jcr:title";
    public static final String CONTENT = "content";
    public static final String APPLICATION_JSON = "application/json";
    public static final String CONTENT_TYPE = "Content-Type";
    public static final String AUTHORIZATION = "Authorization";
    public static final String BEARER = "Bearer";
    public static final String HTML = "html";
    public static final String SLING_SERVLET_DEFAULT = "sling/servlet/default";
    public static final String GRANT_TYPE = "grant_type";
    public static final String CLIENT_CREDENTIALS = "client_credentials";
    public static final String CLIENT_ID = "client_id";
    public static final String CLIENT_SECRET = "client_secret";
    public static final String ACCOUNT_ID = "account_id";
    public static final String SLASH = "/";

    public static final int SOCKET_TIMEOUT = 5000;
    public static final int CONNECT_TIMEOUT = 5000;
}
