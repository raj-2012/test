package com.citibank.contentfactory.core.models;

import java.util.List;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

/**
 * This class represents a model for the hero frame section of the content.
 * It adapts a Sling Resource to this model and provides lists of child resources 
 * and values mapped from AEM ValueMap.
 */

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class HeroFrameModel {

    // Sling Model injects the 'frameType' property from the AEM content node.
    @ValueMapValue
    @Default(values = "none")
    private String frameType;

    // Image path used in the hero frame, injected from AEM content node.
    @ValueMapValue
    private String imagePath;

    // Text that will be displayed on the image in the hero frame.
    @ValueMapValue
    private String textOnImage;

    // Color setting for the hero frame, injected from AEM content node.
    @ValueMapValue
    private String color;

    // Image for a card within the hero frame.
    @ValueMapValue
    private String cardImage;

    // Image AltText for a card within the hero frame.
    @ValueMapValue
    private String cardAltText;

     // Image Title for a card within the hero frame.
     @ValueMapValue
     private String cardTitle;
 
    // Path to the left-side image in the hero frame.
    @ValueMapValue
    private String leftImagePath;

    // Path to the left-side image AltText in the hero frame.
    @ValueMapValue
    private String altText;

    // Path to the left-side image Title in the hero frame.
    @ValueMapValue
    private String title;

    // Color setting for the icons in the hero frame.
    @ValueMapValue
    private String iconColor;

    // Color setting for the bottom strip of the hero frame.
    @ValueMapValue
    private String bottomStripColor;

    // Child resources representing icons within the hero frame.
    @ChildResource
    private List<IconCard> iconsCard;

    // Getter methods to retrieve the injected properties.

    public String getFrameType() {
        return frameType;
    }

    public String getImagePath() {
        return imagePath;
    }

    public String getCardAltText() {
        return cardAltText;
    }

    public String getCardTitle() {
        return cardTitle;
    }

    public String getAltText() {
        return altText;
    }

    public String getTitle() {
        return title;
    }

    public String getTextOnImage() {
        return textOnImage;
    }

    public String getColor() {
        return color;
    }

    public String getCardImage() {
        return cardImage;
    }

    public String getLeftImagePath() {
        return leftImagePath;
    }

    public String getIconColor() {
        return iconColor;
    }

    public String getBottomStripColor() {
        return bottomStripColor;
    }
    
    public List<IconCard> getIconsCard() {
        return iconsCard;
    }
}
