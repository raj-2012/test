package com.citibank.contentfactory.core.models;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

// Sling Model for SFMC AMPscript component
@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class SfmcAmpScriptModel {

    // Stores the ID of the AMPscript
    @ValueMapValue
    private String ampScriptId;

    // Select the type of the AMPscript
    @ValueMapValue
    private String ampScriptType;

    // Getter method for ampScriptId
    public String getAmpScriptId() {
        return ampScriptId;
    }

    // Getter method for ampScriptType
    public String getAmpScriptType() {
        return ampScriptType;
    }
}

