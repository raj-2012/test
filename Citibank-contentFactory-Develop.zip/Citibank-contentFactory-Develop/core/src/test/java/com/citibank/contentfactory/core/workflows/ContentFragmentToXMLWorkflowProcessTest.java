package com.citibank.contentfactory.core.workflows;

import javax.xml.stream.XMLStreamWriter;
import java.io.ByteArrayInputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyBoolean;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.doAnswer;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.ValueMap;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import com.adobe.granite.workflow.WorkflowException;
import com.adobe.granite.workflow.WorkflowSession;
import com.adobe.granite.workflow.exec.WorkflowData;
import com.adobe.granite.workflow.exec.WorkItem;
import com.adobe.granite.workflow.metadata.MetaDataMap;
import com.citibank.contentfactory.core.util.ConstantUtils;
import com.citibank.contentfactory.core.workflows.impl.ContentFragmentToXMLWorkflowProcess;
import com.day.cq.dam.api.AssetManager;

@ExtendWith(MockitoExtension.class)
class ContentFragmentToXMLWorkflowProcessTest {

    @Mock
    private ResourceResolverFactory resourceResolverFactory;

    @Mock
    private ResourceResolver resourceResolver;

    @Mock
    private AssetManager assetManager;

    @InjectMocks
    private ContentFragmentToXMLWorkflowProcess contentFragmentToXMLWorkflowProcess;

    @BeforeEach
    void setUp() throws Exception {
        lenient().when(resourceResolverFactory.getServiceResourceResolver(any())).thenReturn(resourceResolver);
        lenient().when(resourceResolver.adaptTo(AssetManager.class)).thenReturn(assetManager);
    }

    @Test
    void testExecuteWithNoVariations() throws Exception {
        WorkItem workItem = mock(WorkItem.class);
        WorkflowData workflowData = mock(WorkflowData.class);
        when(workflowData.getPayload()).thenReturn("/content/dam/test/contentFragment");
        when(workItem.getWorkflowData()).thenReturn(workflowData);
        Resource contentFragmentResource = mock(Resource.class);
        when(resourceResolver.getResource("/content/dam/test/contentFragment")).thenReturn(contentFragmentResource);
        when(contentFragmentResource.getChild(ConstantUtils.JCR_CONTENT + "/data")).thenReturn(null);
        contentFragmentToXMLWorkflowProcess.execute(workItem, mock(WorkflowSession.class), mock(MetaDataMap.class));
        verify(assetManager, never()).createAsset(anyString(), any(), anyString(), anyBoolean());
    }

    @Test
    void testGenerateXMLFromContentFragment() throws Exception {
        Resource contentFragmentVariation = mock(Resource.class);
        ValueMap valueMap = mock(ValueMap.class);
        when(contentFragmentVariation.getValueMap()).thenReturn(valueMap);
        Map<String, Object> properties = new HashMap<>();
        properties.put("title", "Test Title");
        properties.put("description", "Test Description");
        properties.put("author", "John Doe");
        properties.put("tags", new String[]{"tag1", "tag2", "tag3"});
        properties.put("relatedLinks", Arrays.asList("link1", "link2"));
        properties.put("nested", "/content/dam/test/nestedFragment");
        when(valueMap.keySet()).thenReturn(properties.keySet());
        when(valueMap.get(anyString())).thenAnswer(invocation -> properties.get(invocation.getArgument(0)));
        Resource nestedContentFragment = mock(Resource.class);
        ValueMap nestedValueMap = mock(ValueMap.class);
        when(nestedContentFragment.getValueMap()).thenReturn(nestedValueMap);
        Map<String, Object> nestedProperties = new HashMap<>();
        nestedProperties.put("nestedTitle", "Nested Title");
        nestedProperties.put("nestedTags", new String[]{"nestedTag1", "nestedTag2"});
        nestedProperties.put("nestedAuthor", "Nested Author");
        when(nestedValueMap.keySet()).thenReturn(nestedProperties.keySet());
        when(nestedValueMap.get(anyString())).thenAnswer(invocation -> nestedProperties.get(invocation.getArgument(0)));
        doAnswer(invocation -> {
            String path = invocation.getArgument(0);
            if ("/content/dam/test/nestedFragment/jcr:content/data/master".equals(path)) {
                return nestedContentFragment;
            }
            return null;
        }).when(resourceResolver).getResource(anyString());

        when(contentFragmentVariation.getResourceResolver()).thenReturn(resourceResolver);
        Method generateXMLMethod = ContentFragmentToXMLWorkflowProcess.class.getDeclaredMethod("generateXMLFromContentFragment", Resource.class);
        generateXMLMethod.setAccessible(true);
        String xmlResult = (String) generateXMLMethod.invoke(contentFragmentToXMLWorkflowProcess, contentFragmentVariation);
        assertNotNull(xmlResult);
        assertTrue(xmlResult.contains("<contentFragment>"));
        assertTrue(xmlResult.contains("<title>Test Title</title>"));
        assertTrue(xmlResult.contains("<description>Test Description</description>"));
        assertTrue(xmlResult.contains("<author>John Doe</author>"));
        assertTrue(xmlResult.contains("<tags>"));
        assertTrue(xmlResult.contains("<value>tag1</value>"));
        assertTrue(xmlResult.contains("<value>tag2</value>"));
        assertTrue(xmlResult.contains("<value>tag3</value>"));
        assertTrue(xmlResult.contains("<relatedLinks>"));
        assertTrue(xmlResult.contains("<value>link1</value>"));
        assertTrue(xmlResult.contains("<value>link2</value>"));
        assertTrue(xmlResult.contains("<nestedContentFragment>"));
        assertTrue(xmlResult.contains("<nestedTitle>Nested Title</nestedTitle>"));
        assertTrue(xmlResult.contains("<nestedTags>"));
        assertTrue(xmlResult.contains("<value>nestedTag1</value>"));
        assertTrue(xmlResult.contains("<value>nestedTag2</value>"));
        assertTrue(xmlResult.contains("<nestedAuthor>Nested Author</nestedAuthor>"));
        assertFalse(xmlResult.contains("<testing>"));
    }

    @Test
    void testIsSystemField() throws Exception {
        Method isSystemFieldMethod = ContentFragmentToXMLWorkflowProcess.class.getDeclaredMethod("isSystemField", String.class);
        isSystemFieldMethod.setAccessible(true);

        assertTrue((Boolean) isSystemFieldMethod.invoke(contentFragmentToXMLWorkflowProcess, "jcr:primaryType"));
        assertTrue((Boolean) isSystemFieldMethod.invoke(contentFragmentToXMLWorkflowProcess, "cq:lastModified"));
        assertFalse((Boolean) isSystemFieldMethod.invoke(contentFragmentToXMLWorkflowProcess, "customField"));
    }

    @Test
    void testExecuteWithLoginException() throws Exception {
        WorkItem workItem = mock(WorkItem.class);
        WorkflowSession workflowSession = mock(WorkflowSession.class);
        MetaDataMap metaDataMap = mock(MetaDataMap.class);
        when(resourceResolverFactory.getServiceResourceResolver(any())).thenThrow(LoginException.class);
        assertThrows(WorkflowException.class, () -> {
            contentFragmentToXMLWorkflowProcess.execute(workItem, workflowSession, metaDataMap);
        });
    }

    @Test
    void testWriteFieldWithString() throws Exception {
        XMLStreamWriter xmlWriter = mock(XMLStreamWriter.class);
        String fieldValue = "<test>String with special characters</test>";

        Method writeFieldMethod = ContentFragmentToXMLWorkflowProcess.class.getDeclaredMethod("writeField", XMLStreamWriter.class, Object.class);
        writeFieldMethod.setAccessible(true);

        writeFieldMethod.invoke(contentFragmentToXMLWorkflowProcess, xmlWriter, fieldValue);

        verify(xmlWriter, times(1)).writeCharacters(anyString());
    }

    @Test
    void testWriteFieldWithBoolean() throws Exception {
        XMLStreamWriter xmlWriter = mock(XMLStreamWriter.class);
        Boolean fieldValue = true;
        Method writeFieldMethod = ContentFragmentToXMLWorkflowProcess.class.getDeclaredMethod("writeField", XMLStreamWriter.class, Object.class);
        writeFieldMethod.setAccessible(true);
        writeFieldMethod.invoke(contentFragmentToXMLWorkflowProcess, xmlWriter, fieldValue);
        verify(xmlWriter, times(1)).writeCharacters("true");
    }

    @Test
    void testWriteFieldWithDouble() throws Exception {
        XMLStreamWriter xmlWriter = mock(XMLStreamWriter.class);
        Double fieldValue = 123.456;

        Method writeFieldMethod = ContentFragmentToXMLWorkflowProcess.class.getDeclaredMethod("writeField", XMLStreamWriter.class, Object.class);
        writeFieldMethod.setAccessible(true);

        writeFieldMethod.invoke(contentFragmentToXMLWorkflowProcess, xmlWriter, fieldValue);

        verify(xmlWriter, times(1)).writeCharacters("123.456");
    }

    @Test
    void testWriteFieldWithDate() throws Exception {
        XMLStreamWriter xmlWriter = mock(XMLStreamWriter.class);
        Date fieldValue = new SimpleDateFormat("yyyy-MM-dd").parse("2023-10-25");

        Method writeFieldMethod = ContentFragmentToXMLWorkflowProcess.class.getDeclaredMethod("writeField", XMLStreamWriter.class, Object.class);
        writeFieldMethod.setAccessible(true);

        writeFieldMethod.invoke(contentFragmentToXMLWorkflowProcess, xmlWriter, fieldValue);

        verify(xmlWriter, times(1)).writeCharacters("2023-10-25T00:00:00");
    }

    @Test
    void testWriteFieldWithCalendar() throws Exception {
        XMLStreamWriter xmlWriter = mock(XMLStreamWriter.class);
        Calendar fieldValue = Calendar.getInstance();
        fieldValue.set(2023, Calendar.OCTOBER, 25, 0, 0, 0);
        fieldValue.set(Calendar.MILLISECOND, 0);

        Method writeFieldMethod = ContentFragmentToXMLWorkflowProcess.class.getDeclaredMethod("writeField", XMLStreamWriter.class, Object.class);
        writeFieldMethod.setAccessible(true); // Make the private method accessible

        writeFieldMethod.invoke(contentFragmentToXMLWorkflowProcess, xmlWriter, fieldValue);

        verify(xmlWriter, times(1)).writeCharacters("2023-10-25T00:00:00");
    }

    @Test
    void testWriteFieldWithOtherObject() throws Exception {
        XMLStreamWriter xmlWriter = mock(XMLStreamWriter.class);
        Object fieldValue = new Object();
        Method writeFieldMethod = ContentFragmentToXMLWorkflowProcess.class.getDeclaredMethod("writeField", XMLStreamWriter.class, Object.class);
        writeFieldMethod.setAccessible(true); // Make the private method accessible
        writeFieldMethod.invoke(contentFragmentToXMLWorkflowProcess, xmlWriter, fieldValue);
        verify(xmlWriter, times(1)).writeCharacters(fieldValue.toString());
    }

    @Test
    void testSaveXMLToDAMSuccessfully() throws Exception {
        String xmlData = "<contentFragment><title>Test</title></contentFragment>";
        String payloadPath = "/content/dam/test/contentFragment";
        String variationName = "variation1";
        String fileName = "contentFragment_variation1.xml";
        String targetFolder = "/content/dam/targetFolder";

        Field targetFolderPathField = ContentFragmentToXMLWorkflowProcess.class.getDeclaredField("targetFolderPath");
        ((Field) targetFolderPathField).setAccessible(true);
        targetFolderPathField.set(contentFragmentToXMLWorkflowProcess, targetFolder);

        Resource targetFolderResource = mock(Resource.class);
        when(resourceResolver.getResource(targetFolder)).thenReturn(targetFolderResource);
        when(resourceResolver.adaptTo(AssetManager.class)).thenReturn(assetManager);

        contentFragmentToXMLWorkflowProcess.saveXMLToDAM(resourceResolver, xmlData, payloadPath, variationName);

        verify(assetManager, times(1)).createAsset(
                eq(targetFolder + "/" + fileName),
                any(ByteArrayInputStream.class),
                eq(ConstantUtils.APPLICATION_XML),
                eq(true)
        );
    }

    @Test
    void testSaveXMLToDAMWithAssetManagerUnavailable() throws Exception {
        String xmlData = "<contentFragment><title>Test</title></contentFragment>";
        String payloadPath = "/content/dam/test/contentFragment";
        String variationName = "variation1";
        String targetFolder = "/content/dam/targetFolder";

        Field targetFolderPathField = ContentFragmentToXMLWorkflowProcess.class.getDeclaredField("targetFolderPath");
        targetFolderPathField.setAccessible(true);
        targetFolderPathField.set(contentFragmentToXMLWorkflowProcess, targetFolder);

        Resource targetFolderResource = mock(Resource.class);
        when(resourceResolver.getResource(targetFolder)).thenReturn(targetFolderResource);
        when(resourceResolver.adaptTo(AssetManager.class)).thenReturn(null);

        contentFragmentToXMLWorkflowProcess.saveXMLToDAM(resourceResolver, xmlData, payloadPath, variationName);

        verify(assetManager, never()).createAsset(anyString(), any(), anyString(), anyBoolean());
    }


}