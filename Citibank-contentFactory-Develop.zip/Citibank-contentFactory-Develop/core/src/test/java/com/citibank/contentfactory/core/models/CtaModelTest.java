 package com.citibank.contentfactory.core.models;

 import static junitx.util.PrivateAccessor.setField;
 import static org.junit.jupiter.api.Assertions.assertEquals;
 import static org.mockito.Mockito.when;
 import com.adobe.cq.wcm.core.components.commons.link.Link;
 import com.adobe.cq.wcm.core.components.models.Button;
 import io.wcm.testing.mock.aem.junit5.AemContextExtension;
 import org.junit.jupiter.api.BeforeEach;
 import org.junit.jupiter.api.Test;
 import org.junit.jupiter.api.extension.ExtendWith;
 import org.mockito.InjectMocks;
 import org.mockito.Mock;
 import org.mockito.MockitoAnnotations;
 import org.mockito.junit.jupiter.MockitoExtension;

 @ExtendWith({AemContextExtension.class, MockitoExtension.class})
 class CtaModelTest {

     @Mock
     private Button button;

     @Mock
     private Link<String> mockLink;

     @InjectMocks
     private CtaModel ctaModel;

     @BeforeEach
     public void setUp() throws NoSuchFieldException {
         MockitoAnnotations.openMocks(this);
         setField(ctaModel, "type", "primary");
         setField(ctaModel, "rounded", "true");
         setField(ctaModel, "linkTarget", "_blank");
         setField(ctaModel, "title", "Click me");
         setField(ctaModel, "showImage", "true");
         setField(ctaModel, "fileReference", "/content/dam/image.jpg");
         setField(ctaModel, "width", "100px");
         setField(ctaModel,"linkURL","/content/link");
         setField(ctaModel,"linkUrlTitle","linkUrlTitle");
         setField(ctaModel,"fileAltText","fileAltText");
         setField(ctaModel,"fileTitle","fileTitle");
     }

     @Test
      void testCTAProps() {
         assertEquals("primary", ctaModel.getType());
         assertEquals("true", ctaModel.getRounded());
         assertEquals("_blank", ctaModel.getLinkTarget());
         assertEquals("Click me", ctaModel.getTitle());
         assertEquals("true", ctaModel.getShowImage());
         assertEquals("/content/dam/image.jpg", ctaModel.getFileReference());
         assertEquals("100px", ctaModel.getWidth());
         assertEquals("/content/link",ctaModel.getLinkURL());
         assertEquals("linkUrlTitle",ctaModel.getLinkUrlTitle());
         assertEquals("fileAltText",ctaModel.getFileAltText());
         assertEquals("fileTitle",ctaModel.getFileTitle());
     }

     @Test
     void testButtonProps() {
         when(button.getText()).thenReturn("Click Here");
         when(button.getId()).thenReturn("button-id");
         when(button.getAccessibilityLabel()).thenReturn("Button Accessibility Label");
         when(button.getIcon()).thenReturn("icon1");
         assertEquals("Click Here", ctaModel.getText());
         assertEquals("button-id", ctaModel.getId());
         assertEquals("Button Accessibility Label", ctaModel.getAccessibilityLabel());
         assertEquals("icon1", ctaModel.getIcon());
     }
 }
