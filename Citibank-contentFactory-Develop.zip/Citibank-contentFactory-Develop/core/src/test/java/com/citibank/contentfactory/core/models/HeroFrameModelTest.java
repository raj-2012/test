package com.citibank.contentfactory.core.models;

import java.util.HashMap;
import java.util.Map;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.apache.sling.api.resource.Resource;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;

@ExtendWith(AemContextExtension.class)
class HeroFrameModelTest {

    private final AemContext context = new AemContext();
    private HeroFrameModel heroFrameModel;

    @BeforeEach
    void setUp() {
        Map<String, Object> properties = new HashMap<>();
        properties.put("frameType", "type1");
        properties.put("imagePath", "/content/hero/image.jpg");
        properties.put("textOnImage", "Hero Text");
        properties.put("color", "blue");
        properties.put("cardImage", "/content/hero/cardImage.jpg");
        properties.put("cardAltText", "Card alt Text");
        properties.put("cardTitle", "Card Title");
        properties.put("leftImagePath", "/content/hero/leftImage.jpg");
        properties.put("altText", "Left Image Alt Text");
        properties.put("title", "Left Image Title");
        properties.put("iconColor", "red");
        properties.put("bottomStripColor", "black");
        context.create().resource("/content/hero", properties);

        Map<String, Object> icon1 = new HashMap<>();
        icon1.put("rightSideIcon", "/content/icons/icon1.jpg");
        icon1.put("textOnIcon", "Icon 1");
        icon1.put("width", 50);
        icon1.put("height", 50);
        icon1.put("iconAltText", "Icon Alt Text1");
        icon1.put("iconTitle", "Icon Title1");

        Map<String, Object> icon2 = new HashMap<>();
        icon2.put("rightSideIcon", "/content/icons/icon2.jpg");
        icon2.put("textOnIcon", "Icon 2");
        icon2.put("width", 60);
        icon2.put("height", 60);
        icon2.put("iconAltText", "Icon Alt Text2");
        icon2.put("iconTitle", "Icon Title2");

        context.create().resource("/content/hero/iconsCard/icon1", icon1);
        context.create().resource("/content/hero/iconsCard/icon2", icon2);
        Resource resource = context.resourceResolver().getResource("/content/hero");
        heroFrameModel = resource.adaptTo(HeroFrameModel.class);
    }

    @Test
    void testHeroFrameProperties() {
        assertNotNull(heroFrameModel);
        assertEquals("type1", heroFrameModel.getFrameType());
        assertEquals("/content/hero/image.jpg", heroFrameModel.getImagePath());
        assertEquals("Hero Text", heroFrameModel.getTextOnImage());
        assertEquals("blue", heroFrameModel.getColor());
        assertEquals("/content/hero/cardImage.jpg", heroFrameModel.getCardImage());
        assertEquals("Card alt Text", heroFrameModel.getCardAltText());
        assertEquals("Card Title", heroFrameModel.getCardTitle());
        assertEquals("/content/hero/leftImage.jpg", heroFrameModel.getLeftImagePath());
        assertEquals("Left Image Alt Text", heroFrameModel.getAltText());
        assertEquals("Left Image Title", heroFrameModel.getTitle());
        assertEquals("red", heroFrameModel.getIconColor());
        assertEquals("black", heroFrameModel.getBottomStripColor());
    }

    @Test
    void testIconCards() {
        assertNotNull(heroFrameModel.getIconsCard());
        assertEquals(2, heroFrameModel.getIconsCard().size());

        IconCard iconCard1 = heroFrameModel.getIconsCard().get(0);
        assertEquals("/content/icons/icon1.jpg", iconCard1.getRightSideIcon());
        assertEquals("Icon 1", iconCard1.getTextOnIcon());
        assertEquals(50, iconCard1.getWidth());
        assertEquals(50, iconCard1.getHeight());
        assertEquals("Icon Alt Text1", iconCard1.getIconAltText());
        assertEquals("Icon Title1", iconCard1.getIconTitle());

        IconCard iconCard2 = heroFrameModel.getIconsCard().get(1);
        assertEquals("/content/icons/icon2.jpg", iconCard2.getRightSideIcon());
        assertEquals("Icon 2", iconCard2.getTextOnIcon());
        assertEquals(60, iconCard2.getWidth());
        assertEquals(60, iconCard2.getHeight());
        assertEquals("Icon Alt Text2", iconCard2.getIconAltText());
        assertEquals("Icon Title2", iconCard2.getIconTitle());
    }
}
