package com.citibank.contentfactory.core.service.impl;

import com.citibank.contentfactory.core.config.SFMCConfig;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import javax.inject.Inject;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;

@ExtendWith({AemContextExtension.class, MockitoExtension.class})
class SFMCServiceImplTest {

    @InjectMocks
    private SFMCServiceImpl sfmcService;
    @Inject
    private SFMCConfig sfmcConfig;

    @BeforeEach
    void setUp() {
        sfmcConfig = mock(SFMCConfig.class);
        sfmcService = new SFMCServiceImpl();
        sfmcService.activate(sfmcConfig);
    }

    @Test
    void testAuthUrl() {
        Mockito.when(sfmcConfig.authUrl()).thenReturn("http://auth.test.url");
        String authUrl = sfmcService.authUrl();
        assertEquals("http://auth.test.url", authUrl, "The authUrl should match the value from SFMCConfig");
    }

    @Test
    void testCreateAssetUrl() {
        Mockito.when(sfmcConfig.createAssetUrl()).thenReturn("http://create.asset.url");
        String createAssetUrl = sfmcService.createAssetUrl();
        assertEquals("http://create.asset.url", createAssetUrl, "The createAssetUrl should match the value from SFMCConfig");
    }

    @Test
    void testClientId() {
        Mockito.when(sfmcConfig.clientId()).thenReturn("testClientId");
        String clientId = sfmcService.clientId();
        assertEquals("testClientId", clientId, "The clientId should match the value from SFMCConfig");
    }

    @Test
    void testClientSecret() {
        Mockito.when(sfmcConfig.clientSecret()).thenReturn("testClientSecret");
        String clientSecret = sfmcService.clientSecret();
        assertEquals("testClientSecret", clientSecret, "The clientSecret should match the value from SFMCConfig");
    }

    @Test
    void testAccountId() {
        Mockito.when(sfmcConfig.accountId()).thenReturn("testAccountId");
        String accountId = sfmcService.accountId();
        assertEquals("testAccountId", accountId, "TheaccountId should match the value from SFMCConfig");
    }

    @Test
    void testAssetIdURL() {
        Mockito.when(sfmcConfig.assetIdURL()).thenReturn("/content/dam/accounturl");
        String assetIdURL = sfmcService.assetIdURL();
        assertEquals("/content/dam/accounturl", assetIdURL, "The assetIdURL should match the value from SFMCConfig");
    }
}
