package com.citibank.contentfactory.core.workflows;

import com.adobe.granite.workflow.WorkflowSession;
import com.adobe.granite.workflow.exec.WorkItem;
import com.adobe.granite.workflow.exec.WorkflowData;
import com.citibank.contentfactory.core.util.ConstantUtils;
import org.apache.sling.api.resource.ModifiableValueMap;
import org.apache.sling.api.resource.PersistenceException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import static org.junit.jupiter.api.Assertions.assertNotNull;

class SetApprovedForSFMCPropertyProcessTest {

    @InjectMocks
    private SetApprovedForSFMCPropertyProcess process;

    @Mock
    private WorkItem workItem;

    @Mock
    private WorkflowSession workflowSession;

    @Mock
    private ResourceResolver resourceResolver;

    @Mock
    private Resource pageResource;

    @Mock
    private ModifiableValueMap modifiableValueMap;

    @Mock
    private WorkflowData workflowData;

    private final String pagePath = "/content/my-site/my-page";
    private final String underReview = "underReview";
    private final String approvedForSFMC = "approvedForSFMC";
    private final String testUser = "testUser";
    private final String emailApprovedBy = "emailApprovedBy";

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testExecute_MissingLastModifiedBy() throws PersistenceException {
        when(workItem.getWorkflowData()).thenReturn(workflowData);
        when(workflowData.getPayload()).thenReturn(pagePath);
        when(workflowSession.adaptTo(ResourceResolver.class)).thenReturn(resourceResolver);
        when(resourceResolver.getResource(pagePath + ConstantUtils.SLASH + ConstantUtils.JCR_CONTENT)).thenReturn(pageResource);
        when(pageResource.adaptTo(ModifiableValueMap.class)).thenReturn(modifiableValueMap);
        when(modifiableValueMap.get(underReview, Boolean.class)).thenReturn(true);
        when(modifiableValueMap.get(ConstantUtils.CQ_LAST_MODIFIED_BY, String.class)).thenReturn(null);
        process.execute(workItem, workflowSession, null);
        verify(modifiableValueMap).put(underReview, false);
        verify(modifiableValueMap).put(approvedForSFMC, true);
        verify(modifiableValueMap, never()).put(eq(emailApprovedBy), anyString());
        verify(resourceResolver).commit();
    }

    @Test
    void testExecute_ResourceNotFound() throws PersistenceException {
        when(workItem.getWorkflowData()).thenReturn(workflowData);
        when(workflowData.getPayload()).thenReturn(pagePath);
        when(workflowSession.adaptTo(ResourceResolver.class)).thenReturn(resourceResolver);
        when(resourceResolver.getResource(pagePath + ConstantUtils.SLASH + ConstantUtils.JCR_CONTENT)).thenReturn(null);
        process.execute(workItem, workflowSession, null);
        verify(resourceResolver, never()).commit();
    }

    @Test
    void testExecute_PersistenceException() throws PersistenceException {
        when(workItem.getWorkflowData()).thenReturn(workflowData);
        when(workflowData.getPayload()).thenReturn(pagePath);
        when(workflowSession.adaptTo(ResourceResolver.class)).thenReturn(resourceResolver);
        when(resourceResolver.getResource(pagePath + ConstantUtils.SLASH + ConstantUtils.JCR_CONTENT)).thenReturn(pageResource);
        when(pageResource.adaptTo(ModifiableValueMap.class)).thenReturn(modifiableValueMap);
        when(modifiableValueMap.get(underReview, Boolean.class)).thenReturn(true);
        when(modifiableValueMap.get(ConstantUtils.CQ_LAST_MODIFIED_BY, String.class)).thenReturn(testUser);
        doThrow(new PersistenceException("Test Exception")).when(resourceResolver).commit();
        process.execute(workItem, workflowSession, null);
        assertNotNull(workItem);
    }
}