package com.citibank.contentfactory.core.util;

import org.junit.jupiter.api.Test;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class ConstantUtilsTest {

    @Test
    void testPrivateConstructor() throws NoSuchMethodException {
        Constructor<ConstantUtils> constructor = ConstantUtils.class.getDeclaredConstructor();
        constructor.setAccessible(true);
        InvocationTargetException thrown = assertThrows(InvocationTargetException.class, constructor::newInstance);
        assertEquals("ConstantUtils class", thrown.getCause().getMessage());
    }
}
