package com.citibank.contentfactory.core.models;

import java.util.Iterator;
import java.util.Map;
import static junitx.util.PrivateAccessor.setField;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import com.adobe.cq.dam.cfm.ContentElement;
import com.adobe.cq.dam.cfm.ContentFragment;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;


@ExtendWith({AemContextExtension.class, MockitoExtension.class})
class NestedContentFragmentModelTest {

    @Mock
    private Resource resource;

    @Mock
    private ResourceResolver resourceResolver;

    @Mock
    private ContentFragment contentFragment;

    @Mock
    private ContentElement contentElement;

    @InjectMocks
    private NestedContentFragmentModel model;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);  // Use openMocks() instead of initMocks()
        when(resource.getResourceResolver()).thenReturn(resourceResolver);
    }

    @Test
    void testInitWithSingleValidReference() throws NoSuchFieldException {
        String cfReference = "/content/dam/fragment1";
        when(resourceResolver.getResource(cfReference)).thenReturn(resource);
        when(resource.adaptTo(ContentFragment.class)).thenReturn(contentFragment);
        Iterator<ContentElement> contentElements = mock(Iterator.class);
        when(contentFragment.getElements()).thenReturn(contentElements);
        when(contentElements.hasNext()).thenReturn(true, false);
        when(contentElements.next()).thenReturn(contentElement);
        when(contentElement.getName()).thenReturn("element1");
        when(contentElement.getContent()).thenReturn("content1");
        setField(model, "cfReference", cfReference);
        model.init();
        assertEquals(1, model.getFragmentElementsList().size());
        Map<String, String> fragmentData = model.getFragmentElementsList().get(0);
        assertEquals("content1", fragmentData.get("element1"));
    }
}
