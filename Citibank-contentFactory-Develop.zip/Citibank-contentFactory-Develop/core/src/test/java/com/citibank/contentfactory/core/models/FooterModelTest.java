package com.citibank.contentfactory.core.models;

import java.util.HashMap;
import java.util.Map;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import org.apache.sling.api.resource.Resource;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;

@ExtendWith({AemContextExtension.class, MockitoExtension.class})
class FooterModelTest {


    private final AemContext context = new AemContext();
    private FooterModel footerModel;

    @BeforeEach
    void setUp() {
        context.addModelsForClasses(FooterModel.class, FooterCards.class, SocialIcons.class);
        context.create().resource("/content/footer",
                "jcr:primaryType", "nt:unstructured");

        Map<String, Object> footerCard1 = new HashMap<>();
        footerCard1.put("appLink", "https://example.com/app1");
        footerCard1.put("appIcons", "icon1");
        footerCard1.put("appLinkTitle", "appLinkTitle1");
        footerCard1.put("appIconAltText", "appIconAltText1");
        footerCard1.put("appIconTitle", "appIconTitle1");

        Map<String, Object> footerCard2 = new HashMap<>();
        footerCard2.put("appLink", "https://example.com/app2");
        footerCard2.put("appIcons", "icon2");
        footerCard2.put("appLinkTitle", "appLinkTitle2");
        footerCard2.put("appIconAltText", "appIconAltText2");
        footerCard2.put("appIconTitle", "appIconTitle2");

        context.create().resource("/content/footer/footerCard/card1", footerCard1);
        context.create().resource("/content/footer/footerCard/card2", footerCard2);

        Map<String, Object> socialIcon1 = new HashMap<>();
        socialIcon1.put("socialMediaLink", "https://facebook.com");
        socialIcon1.put("icons", "facebook-icon");
        socialIcon1.put("socialMediaLinkTitle", "facebook");
        socialIcon1.put("iconAltText", "facebook");
        socialIcon1.put("iconTitle", "facebook");

        Map<String, Object> socialIcon2 = new HashMap<>();
        socialIcon2.put("socialMediaLink", "https://twitter.com");
        socialIcon2.put("icons", "twitter-icon");
        socialIcon2.put("socialMediaLinkTitle", "twitter");
        socialIcon2.put("iconAltText", "twitter");
        socialIcon2.put("iconTitle", "twitter");

        context.create().resource("/content/footer/socialMediaIcons/icon1", socialIcon1);
        context.create().resource("/content/footer/socialMediaIcons/icon2", socialIcon2);
        Resource footerResource = context.resourceResolver().getResource("/content/footer");
        footerModel = footerResource.adaptTo(FooterModel.class);
    }

    @Test
    void testGetFooterCard() {
        assertNotNull(footerModel);
        assertNotNull(footerModel.getFooterCard());
        assertEquals(2, footerModel.getFooterCard().size());
        assertEquals("https://example.com/app1", footerModel.getFooterCard().get(0).getAppLink());
        assertEquals("icon1", footerModel.getFooterCard().get(0).getAppIcons());
        assertEquals("appLinkTitle1", footerModel.getFooterCard().get(0).getAppLinkTitle());
        assertEquals("appIconAltText1", footerModel.getFooterCard().get(0).getAppIconAltText());
        assertEquals("appIconTitle1", footerModel.getFooterCard().get(0).getAppIconTitle());
        assertEquals("https://example.com/app2", footerModel.getFooterCard().get(1).getAppLink());
        assertEquals("icon2", footerModel.getFooterCard().get(1).getAppIcons());
        assertEquals("appLinkTitle2", footerModel.getFooterCard().get(1).getAppLinkTitle());
        assertEquals("appIconAltText2", footerModel.getFooterCard().get(1).getAppIconAltText());
        assertEquals("appIconTitle2", footerModel.getFooterCard().get(1).getAppIconTitle());
    }
    @Test
    void testGetSocialMediaIcons() {
        assertNotNull(footerModel);
        assertNotNull(footerModel.getSocialMediaIcons());
        assertEquals(2, footerModel.getSocialMediaIcons().size());
        assertEquals("https://facebook.com", footerModel.getSocialMediaIcons().get(0).getSocialMediaLink());
        assertEquals("facebook-icon", footerModel.getSocialMediaIcons().get(0).getIcons());
        assertEquals("facebook", footerModel.getSocialMediaIcons().get(0).getSocialMediaLinkTitle());
        assertEquals("facebook",footerModel.getSocialMediaIcons().get(0).getIconAltText());
        assertEquals("facebook",footerModel.getSocialMediaIcons().get(0).getIconTitle());

        assertEquals("https://twitter.com", footerModel.getSocialMediaIcons().get(1).getSocialMediaLink());
        assertEquals("twitter-icon", footerModel.getSocialMediaIcons().get(1).getIcons());
        assertEquals("twitter", footerModel.getSocialMediaIcons().get(1).getSocialMediaLinkTitle());
        assertEquals("twitter",footerModel.getSocialMediaIcons().get(1).getIconAltText());
        assertEquals("twitter",footerModel.getSocialMediaIcons().get(1).getIconTitle());
    }
}
