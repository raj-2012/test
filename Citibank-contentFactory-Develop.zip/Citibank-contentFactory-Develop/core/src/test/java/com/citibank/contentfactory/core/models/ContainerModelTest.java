package com.citibank.contentfactory.core.models;

import java.awt.Container;
import static junitx.util.PrivateAccessor.setField;
import static org.junit.jupiter.api.Assertions.assertEquals;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;



@ExtendWith({AemContextExtension.class, MockitoExtension.class})
class ContainerModelTest {
    @Mock
    private Container container;
    @InjectMocks
    private ContainerModel containerModel;

    @BeforeEach
    void setUp() throws NoSuchFieldException {
        MockitoAnnotations.openMocks(this);
        setField(containerModel, "blockName", "citiBlockName");
        setField(containerModel, "slotName", "citiSlotName");
        setField(containerModel, "blockSlotType", "citiBlockSlotType");
        setField(containerModel, "slotMessage", "Drop slots or content here");
        setField(containerModel, "backgroundColor", "transparent");
    }

    @Test
    void getTestMethods() {
        assertEquals("citiBlockName", containerModel.getBlockName());
        assertEquals("citiSlotName", containerModel.getSlotName());
        assertEquals("citiBlockSlotType", containerModel.getBlockSlotType());
        assertEquals("Drop slots or content here", containerModel.getSlotMessage());
        assertEquals("transparent", containerModel.getBackgroundColor());
    }
}