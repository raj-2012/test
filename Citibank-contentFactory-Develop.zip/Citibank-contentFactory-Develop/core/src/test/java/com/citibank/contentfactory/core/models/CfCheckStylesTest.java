package com.citibank.contentfactory.core.models;

import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.apache.sling.api.resource.Resource;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(AemContextExtension.class)
class CfCheckStylesTest {

    private final AemContext context = new AemContext();
    private Resource resource;

    @BeforeEach
    void setUp() {
        context.addModelsForClasses(CfCheckStyles.class);
    }

    @Test
    void testHasStyleIds_WhenStyleIdsArePresent() {
        resource = context.create().resource("/content/cf-test",
                "cq:styleIds", new String[]{"style1", "style2"});
        
        CfCheckStyles cfCheckStyles = resource.adaptTo(CfCheckStyles.class);
        assertNotNull(cfCheckStyles, "CfCheckStyles model should not be null");
        assertTrue(cfCheckStyles.hasStyleIds(), "Style IDs should be present");
        assertArrayEquals(new String[]{"style1", "style2"}, cfCheckStyles.getStyleIds(), "Style IDs should match the provided values");
    }
    @Test
    void testHasStyleIds_WhenStyleIdsAreNotPresent() {
        Resource noStyleIdsResource = context.create().resource("/content/cf-no-style");
        CfCheckStyles cfCheckStyles = noStyleIdsResource.adaptTo(CfCheckStyles.class);
        assertNotNull(cfCheckStyles, "CfCheckStyles model should not be null");
        assertFalse(cfCheckStyles.hasStyleIds(), "hasStyleIds should return false when style IDs are not present");
    }
    @Test
    void testHasStyleIds_WhenStyleIdsIsEmptyArray() {
        Resource emptyStyleIdsResource = context.create().resource("/content/cf-empty-style",
                "cq:styleIds", new String[]{});
        
        CfCheckStyles cfCheckStyles = emptyStyleIdsResource.adaptTo(CfCheckStyles.class);
        assertNotNull(cfCheckStyles, "CfCheckStyles model should not be null");
        assertFalse(cfCheckStyles.hasStyleIds(), "hasStyleIds should return false for an empty style IDs array");
        assertArrayEquals(new String[]{}, cfCheckStyles.getStyleIds(), "Style IDs should be an empty array");
    }
}