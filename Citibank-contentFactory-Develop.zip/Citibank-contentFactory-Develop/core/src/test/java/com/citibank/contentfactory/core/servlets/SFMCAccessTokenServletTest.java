package com.citibank.contentfactory.core.servlets;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringReader;
import java.lang.reflect.Method;
import javax.jcr.Session;
import javax.servlet.http.HttpServletResponse;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.citibank.contentfactory.core.service.GETApiService;
import com.citibank.contentfactory.core.service.POSTAPIService;
import com.citibank.contentfactory.core.service.SFMCService;
import com.citibank.contentfactory.core.util.ConstantUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.request.RequestPathInfo;
import org.apache.sling.api.resource.ModifiableValueMap;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

class SFMCAccessTokenServletTest {

    @InjectMocks
    private SFMCAccessTokenServlet servlet;

    @Mock
    private SFMCService sfmcService;

    @Mock
    private POSTAPIService postServiceAPI;

    @Mock
    private GETApiService getApiService;

    @Mock
    private SlingHttpServletRequest request;

    @Mock
    private SlingHttpServletResponse response;

    @Mock
    private ResourceResolver resourceResolver;

    @Mock
    private RequestPathInfo requestPathInfo;

    @Mock
    private Session session;

    @Mock
    private Resource pageResource;

    @Mock
    private ModifiableValueMap properties;
    private static final String CONTENT_DAM_TEST = "/content/dam/test";
    private static final String CLIENT_ID = "client_id";
    private static final String CLIENT_SECRET = "client_secret";
    private static final String ACCOUNT_ID = "account_id";
    private static final String TEST_USER = "testUser";
    private static final String REMOTE_USER = "remoteUser";

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        when(request.getRequestPathInfo()).thenReturn(requestPathInfo);
        when(requestPathInfo.getResourcePath()).thenReturn(CONTENT_DAM_TEST);
    }

    @Test
    void testDoPost_EmptyPayload() throws IOException {
        when(request.getReader()).thenReturn(new BufferedReader(new StringReader("")));
        servlet.doPost(request, response);
        verify(response).setStatus(HttpServletResponse.SC_BAD_REQUEST);
    }

    @Test
    void testDoPost_ValidAccessToken() throws Exception {
        when(sfmcService.clientId()).thenReturn(CLIENT_ID);
        when(sfmcService.clientSecret()).thenReturn(CLIENT_SECRET);
        when(sfmcService.accountId()).thenReturn(ACCOUNT_ID);
        when(postServiceAPI.getAccessTokenPOSTAPI(eq(response), any(String.class))).thenReturn("validAccessToken");
        String payLoad = "{\"test\":\"data\"}";
        when(request.getReader()).thenReturn(new BufferedReader(new StringReader(payLoad)));
        when(request.getResourceResolver()).thenReturn(resourceResolver);
        when(resourceResolver.adaptTo(Session.class)).thenReturn(session);
        when(request.getResourceResolver()).thenReturn(resourceResolver);
        when(resourceResolver.getResource(CONTENT_DAM_TEST + ConstantUtils.SLASH + ConstantUtils.JCR_CONTENT)).thenReturn(pageResource);
        when(pageResource.adaptTo(ModifiableValueMap.class)).thenReturn(properties);
        servlet.doPost(request, response);
        verify(resourceResolver).commit();
    }

    @Test
    void testGetSFMCAuthToken() throws Exception {
        when(sfmcService.clientId()).thenReturn(CLIENT_ID);
        when(sfmcService.clientSecret()).thenReturn(CLIENT_SECRET);
        when(sfmcService.accountId()).thenReturn(ACCOUNT_ID);
        String expectedToken = "accessToken";
        when(postServiceAPI.getAccessTokenPOSTAPI(eq(response), any(String.class))).thenReturn(expectedToken);
        Method method = SFMCAccessTokenServlet.class.getDeclaredMethod("getSFMCAuthToken", SlingHttpServletResponse.class);
        method.setAccessible(true);
        String actualToken = (String) method.invoke(servlet, response);
        assertEquals(expectedToken, actualToken);
    }

    @Test
    void testGetUserFromSession_WithSession() throws Exception {
        when(request.getResourceResolver()).thenReturn(resourceResolver);
        when(resourceResolver.adaptTo(Session.class)).thenReturn(session);
        when(session.getUserID()).thenReturn(TEST_USER);
        Method method = SFMCAccessTokenServlet.class.getDeclaredMethod("getUserFromSession", SlingHttpServletRequest.class);
        method.setAccessible(true);
        String userId = (String) method.invoke(servlet, request);
        assertEquals(TEST_USER, userId);
    }

    @Test
    void testGetUserFromSession_WithoutSession() throws Exception {
        when(request.getResourceResolver()).thenReturn(resourceResolver);
        when(resourceResolver.adaptTo(Session.class)).thenReturn(null);
        when(request.getAttribute("org.osgi.service.http.authentication.remote.user")).thenReturn(REMOTE_USER);
        Method method = SFMCAccessTokenServlet.class.getDeclaredMethod("getUserFromSession", SlingHttpServletRequest.class);
        method.setAccessible(true);
        String userId = (String) method.invoke(servlet, request);
        assertEquals(REMOTE_USER, userId);
    }

    @Test
    void testDoGet_ValidAccessToken() throws Exception {
        when(sfmcService.clientId()).thenReturn(CLIENT_ID);
        when(sfmcService.clientSecret()).thenReturn(CLIENT_SECRET);
        when(sfmcService.accountId()).thenReturn(ACCOUNT_ID);
        when(postServiceAPI.getAccessTokenPOSTAPI(eq(response), any(String.class))).thenReturn("validAccessToken");
        String ID = "71860";
        when(request.getParameter("id")).thenReturn(ID);
        when(request.getResourceResolver()).thenReturn(resourceResolver);
        when(resourceResolver.adaptTo(Session.class)).thenReturn(session);
        when(request.getResourceResolver()).thenReturn(resourceResolver);
        when(resourceResolver.getResource(CONTENT_DAM_TEST + ConstantUtils.SLASH + ConstantUtils.JCR_CONTENT)).thenReturn(pageResource);
        when(pageResource.adaptTo(ModifiableValueMap.class)).thenReturn(properties);
        servlet.doGet(request, response);
        assertNotNull(resourceResolver);
    }
}
