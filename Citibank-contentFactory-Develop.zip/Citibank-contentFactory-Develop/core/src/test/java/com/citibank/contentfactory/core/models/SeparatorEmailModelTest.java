package com.citibank.contentfactory.core.models;

import static junitx.util.PrivateAccessor.setField;
import static org.junit.jupiter.api.Assertions.assertEquals;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;


@ExtendWith({AemContextExtension.class, MockitoExtension.class})
class SeparatorEmailModelTest {

    @InjectMocks
    private SeparatorEmailModel separatorEmaiModel;

    @BeforeEach
    public void setUp() throws NoSuchFieldException {
        MockitoAnnotations.openMocks(this);
        setField(separatorEmaiModel, "height", "30");
    }

    @Test
    void testGetHeight() {
        assertEquals("30", separatorEmaiModel.getHeight());
    }   
}