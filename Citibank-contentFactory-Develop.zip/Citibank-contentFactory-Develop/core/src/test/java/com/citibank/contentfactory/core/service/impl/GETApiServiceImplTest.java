package com.citibank.contentfactory.core.service.impl;

import com.citibank.contentfactory.core.service.SFMCService;
import com.citibank.contentfactory.core.util.ConstantUtils;
import org.apache.http.HttpEntity;
import org.apache.http.StatusLine;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.osgi.services.HttpClientBuilderFactory;
import org.apache.sling.api.SlingHttpServletResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayInputStream;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class GETApiServiceImplTest {

    @InjectMocks
    private GETApiServiceImpl getApiService;

    @Mock
    private HttpClientBuilderFactory clientBuilderFactory;

    @Mock
    private SFMCService sfmcService;

    @Mock
    private CloseableHttpClient httpClient;

    @Mock
    private CloseableHttpResponse httpResponse;

    @Mock
    private SlingHttpServletResponse slingHttpServletResponse;

    @Mock
    private HttpClientBuilder clientBuilder;

    @Mock
    private StatusLine statusLine;

    @Mock
    private PrintWriter writer;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetGETAPIResponse_Success() throws Exception {
        String accessToken = "test-access-token";
        String payload = "71860";
        String jsonResponse = "{\"result\":\"success\"}";
        when(sfmcService.createAssetUrl()).thenReturn("https://citi.com/create-asset");
        when(clientBuilderFactory.newBuilder()).thenReturn(clientBuilder);
        when(clientBuilder.build()).thenReturn(httpClient);
        when(httpResponse.getStatusLine()).thenReturn(statusLine);
        when(statusLine.getStatusCode()).thenReturn(HttpServletResponse.SC_OK);
        HttpEntity entity = mock(HttpEntity.class);
        when(entity.getContent()).thenReturn(new ByteArrayInputStream(jsonResponse.getBytes(StandardCharsets.UTF_8)));
        when(entity.getContentLength()).thenReturn((long) jsonResponse.length());
        when(httpResponse.getEntity()).thenReturn(entity);
        when(httpClient.execute(any(HttpGet.class))).thenReturn(httpResponse);
        when(slingHttpServletResponse.getContentType()).thenReturn(ConstantUtils.APPLICATION_JSON);
        when(slingHttpServletResponse.getWriter()).thenReturn(writer);
        getApiService.getGETAPIResponse(slingHttpServletResponse, accessToken, payload);
        verify(slingHttpServletResponse).setStatus(HttpServletResponse.SC_OK);
    }
}