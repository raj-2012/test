package com.citibank.contentfactory.core.models;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.HashMap;
import java.util.Map;

import org.apache.sling.api.resource.Resource;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import com.day.cq.wcm.api.Page;

import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;

@ExtendWith(AemContextExtension.class)
class SfmcModelTest {

    private final AemContext context = new AemContext();
    private SfmcModel sfmcModel;

    @BeforeEach
    void setUp() {
        Map<String, Object> pageProperties = new HashMap<>();
        pageProperties.put("underReview", true);
        pageProperties.put("approvedForSFMC", false);
        Page currentPage = context.create().page("/content/mypage", null, pageProperties).adaptTo(Page.class);
        Map<String, Object> modelProperties = new HashMap<>();
        modelProperties.put("jsonPath", "/content/my/json/path");
        modelProperties.put("folderId", "1234");
        context.create().resource("/content/sfmcModel", modelProperties);
        Resource resource = context.resourceResolver().getResource("/content/sfmcModel");
        context.currentResource(resource); 
        context.currentPage(currentPage);  
        sfmcModel = context.request().adaptTo(SfmcModel.class);  
    }

    @Test
    void testSfmcModel() {
        assertNotNull(sfmcModel);
        assertEquals(true, sfmcModel.getUnderReview());
        assertEquals(false, sfmcModel.getApprovedForSFMC());
        assertEquals(null, sfmcModel.getJsonPath()); 
        assertEquals(null, sfmcModel.getFolderId()); 
    }
}
