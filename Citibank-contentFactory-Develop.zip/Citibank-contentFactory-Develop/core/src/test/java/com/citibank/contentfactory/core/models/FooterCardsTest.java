package com.citibank.contentfactory.core.models;

import java.util.HashMap;
import java.util.Map;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import io.wcm.testing.mock.aem.junit5.AemContext;
import org.apache.sling.api.resource.Resource;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith(AemContextExtension.class)
class FooterCardsTest {

    private final AemContext context = new AemContext();

    private FooterCards footerCards;

    @BeforeEach
    void setUp() {
        context.addModelsForClasses(FooterCards.class);
        Map<String, Object> footerCard = new HashMap<>();
        footerCard.put("appLink", "app-link-1");
        footerCard.put("appIcons", "app-icon-1");
        context.create().resource("/content/footerCard", footerCard);
        Resource resource = context.resourceResolver().getResource("/content/footerCard");
        footerCards = resource.adaptTo(FooterCards.class);
    }
    @Test
    void testFooterCards() {
        assertNotNull(footerCards);
        assertEquals("app-link-1", footerCards.getAppLink());
        assertEquals("app-icon-1", footerCards.getAppIcons());
    }
}
