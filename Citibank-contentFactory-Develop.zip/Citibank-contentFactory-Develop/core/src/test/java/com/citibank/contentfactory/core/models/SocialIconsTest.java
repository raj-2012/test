package com.citibank.contentfactory.core.models;

import java.util.HashMap;
import java.util.Map;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import io.wcm.testing.mock.aem.junit5.AemContext;
import org.apache.sling.api.resource.Resource;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith(AemContextExtension.class)
class SocialIconsTest {

    private final AemContext context = new AemContext();
    private SocialIcons socialIcons;

    @BeforeEach
    void setUp() {
        context.addModelsForClasses(SocialIcons.class);
        Map<String, Object> socialIcon = new HashMap<>();
        socialIcon.put("socialMediaLink", "http://example.com");
        socialIcon.put("icons", "logo-icon");

        context.create().resource("/content/socialIcons", socialIcon);
        Resource resource = context.resourceResolver().getResource("/content/socialIcons");
        socialIcons = resource.adaptTo(SocialIcons.class);
    }

    @Test
    void testSocialIcons() {
        assertNotNull(socialIcons);
        assertEquals("http://example.com", socialIcons.getSocialMediaLink());
        assertEquals("logo-icon", socialIcons.getIcons());
    }
}
