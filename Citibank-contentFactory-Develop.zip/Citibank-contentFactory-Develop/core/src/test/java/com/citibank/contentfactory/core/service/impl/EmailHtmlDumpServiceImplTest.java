package com.citibank.contentfactory.core.service.impl;

import com.citibank.contentfactory.core.config.EmailHtmlDumpConfig;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import javax.inject.Inject;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;


class EmailHtmlDumpServiceImplTest {

    @InjectMocks
    private EmailHtmlDumpServiceImpl emailHtmlDumpService;

    @Inject
    private EmailHtmlDumpConfig emailHtmlDumpConfig;

    @BeforeEach
    void setUp() {
        emailHtmlDumpConfig = mock(EmailHtmlDumpConfig.class);
        emailHtmlDumpService = new EmailHtmlDumpServiceImpl();
        emailHtmlDumpService.activate(emailHtmlDumpConfig);
    }

    @Test
    void testDamPath() {
        Mockito.when(emailHtmlDumpConfig.emailHtmlDumpFolderPath()).thenReturn("/content/citibbank/dam");
        String damPath = emailHtmlDumpService.emailHtmlDumpFolderPath();
        assertEquals("/content/citibbank/dam", damPath, "The authUrl should match the value from SFMCConfig");
    }
}