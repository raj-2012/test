package com.citibank.contentfactory.core.workflows;

import javax.jcr.Session;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyBoolean;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import com.adobe.granite.workflow.WorkflowSession;
import com.adobe.granite.workflow.exec.WorkItem;
import com.adobe.granite.workflow.exec.WorkflowData;
import com.adobe.granite.workflow.metadata.MetaDataMap;
import com.day.cq.contentsync.handler.util.RequestResponseFactory;
import com.day.cq.dam.api.Asset;
import com.day.cq.dam.api.AssetManager;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.engine.SlingRequestProcessor;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

class EmailHTMLDumpWorkflowTest {

    @Mock
    private WorkItem workItem;

    @Mock
    private WorkflowSession workflowSession;

    @Mock
    private WorkflowData workflowData;

    @Mock
    private MetaDataMap metaDataMap;

    @Mock
    private RequestResponseFactory requestResponseFactory;

    @Mock
    private SlingRequestProcessor requestProcessor;

    @Mock
    private ResourceResolver resourceResolver;

    @Mock
    private Session session;

    @Mock
    private AssetManager assetManager;

    @Mock
    private HttpServletRequest request;

    @InjectMocks
    private EmailHTMLDumpWorkflow workflow = new EmailHTMLDumpWorkflow();

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        when(workItem.getWorkflowData()).thenReturn(workflowData);
        when(workflowData.getPayload()).thenReturn("/content/test-page");
        when(workflowData.getPayloadType()).thenReturn("JCR_PATH");
        when(workflowSession.adaptTo(ResourceResolver.class)).thenReturn(resourceResolver);
        when(workflowSession.adaptTo(Session.class)).thenReturn(session);
        when(resourceResolver.adaptTo(AssetManager.class)).thenReturn(assetManager);
    }

    @Test
    void testExecuteSuccessful() throws Exception {
        when(requestResponseFactory.createRequest(eq("GET"), anyString())).thenReturn(request);
        when(resourceResolver.getResource(anyString())).thenReturn(null);
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        HttpServletResponse response = requestResponseFactory.createResponse(outputStream);
        doNothing().when(requestProcessor).processRequest(any(HttpServletRequest.class), eq(response), eq(resourceResolver));
        outputStream.write("<html><body><p>Test HTML content</p></body></html>".getBytes(StandardCharsets.UTF_8));
        workflow.execute(workItem, workflowSession, metaDataMap);
        String resultContent = new String(outputStream.toByteArray(), StandardCharsets.UTF_8);
        System.out.println("Output Stream Content: " + resultContent);  // Log the content of outputStream
        assertFalse(resultContent.isEmpty(), "The HTML content should not be empty");
        assertTrue(resultContent.contains("Test HTML content"), "The HTML content should contain the test content");
        verify(session, times(1)).logout();
    }

    @Test
    void testExecuteAssetAlreadyExists() throws Exception {
        when(requestResponseFactory.createRequest(eq("GET"), anyString())).thenReturn(request);
        Resource mockResource = mock(Resource.class);
        Asset mockAsset = mock(Asset.class);
        when(resourceResolver.getResource(anyString())).thenReturn(mockResource);
        when(mockResource.adaptTo(Asset.class)).thenReturn(mockAsset);
        workflow.execute(workItem, workflowSession, metaDataMap);
        verify(assetManager, never()).createAsset(anyString(), any(ByteArrayInputStream.class), anyString(), anyBoolean());
    }

    @Test
    void testExecuteInvalidPayloadType() throws Exception {
        when(workflowData.getPayloadType()).thenReturn("OTHER_TYPE");
        workflow.execute(workItem, workflowSession, metaDataMap);
        verify(requestResponseFactory, never()).createRequest(anyString(), anyString());
    }
}