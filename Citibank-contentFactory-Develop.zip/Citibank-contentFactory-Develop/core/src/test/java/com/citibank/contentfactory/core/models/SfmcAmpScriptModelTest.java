package com.citibank.contentfactory.core.models;

import java.util.HashMap;
import java.util.Map;
import static org.junit.jupiter.api.Assertions.assertEquals;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.apache.sling.api.resource.Resource;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith(AemContextExtension.class)
class SfmcAmpScriptModelTest {

    private final AemContext context = new AemContext();
    private SfmcAmpScriptModel sfmcAmpScriptModel;

    @BeforeEach
    void setUp() {
        context.addModelsForClasses(SfmcAmpScriptModel.class);
        Map<String, Object> properties = new HashMap<>();
        properties.put("ampScriptId", "68716");
        properties.put("ampScriptType", "global");

        Resource resource=context.create().resource("/content/test/sfmcampscript", properties);
        sfmcAmpScriptModel = resource.adaptTo(SfmcAmpScriptModel.class);
    }

    @Test
    void testSfmcAmpScriptModel() {
        assertEquals("68716", sfmcAmpScriptModel.getAmpScriptId());
        assertEquals("global", sfmcAmpScriptModel.getAmpScriptType());
    }
}
