package com.citibank.contentfactory.core.workflows;

import com.adobe.granite.workflow.WorkflowSession;
import com.adobe.granite.workflow.exec.WorkItem;
import com.adobe.granite.workflow.exec.WorkflowData;
import com.citibank.contentfactory.core.util.ConstantUtils;
import org.apache.sling.api.resource.ModifiableValueMap;
import org.apache.sling.api.resource.PersistenceException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class SetUnderReviewPropertyProcessTest {

    @InjectMocks
    private SetUnderReviewPropertyProcess process;

    @Mock
    private WorkItem workItem;

    @Mock
    private WorkflowSession workflowSession;

    @Mock
    private ResourceResolver resourceResolver;

    @Mock
    private Resource pageResource;

    @Mock
    private ModifiableValueMap modifiableValueMap;

    @Mock
    private WorkflowData workflowData;

    private final String pagePath = "/content/my-site/my-page";

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
        process = new SetUnderReviewPropertyProcess();
    }

    @Test
    void testExecute_Success() throws PersistenceException {
        when(workItem.getWorkflowData()).thenReturn(workflowData);
        when(workItem.getWorkflowData().getPayload()).thenReturn(pagePath);
        when(workflowSession.adaptTo(ResourceResolver.class)).thenReturn(resourceResolver);
        when(resourceResolver.getResource(pagePath + ConstantUtils.SLASH + ConstantUtils.JCR_CONTENT)).thenReturn(pageResource);
        when(pageResource.adaptTo(ModifiableValueMap.class)).thenReturn(modifiableValueMap);
        ArgumentCaptor<String> keyCaptor = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Boolean> valueCaptor = ArgumentCaptor.forClass(Boolean.class);
        process.execute(workItem, workflowSession, null);
        verify(modifiableValueMap).put(keyCaptor.capture(), valueCaptor.capture());
        assertEquals("underReview", keyCaptor.getValue());
        assertTrue(valueCaptor.getValue());
        verify(resourceResolver).commit();
    }

    @Test
    void testExecute_PageResourceNotFound() throws PersistenceException {
        when(workItem.getWorkflowData()).thenReturn(workflowData);
        when(workItem.getWorkflowData().getPayload()).thenReturn(pagePath);
        when(workflowSession.adaptTo(ResourceResolver.class)).thenReturn(resourceResolver);
        when(resourceResolver.getResource(pagePath + ConstantUtils.SLASH + ConstantUtils.JCR_CONTENT)).thenReturn(null);
        process.execute(workItem, workflowSession, null);
        verify(resourceResolver, never()).commit();
    }

    @Test
    void testExecute_PersistenceException() throws PersistenceException {
        when(workItem.getWorkflowData()).thenReturn(workflowData);
        when(workItem.getWorkflowData().getPayload()).thenReturn(pagePath);
        when(workflowSession.adaptTo(ResourceResolver.class)).thenReturn(resourceResolver);
        when(resourceResolver.getResource(pagePath + ConstantUtils.SLASH + ConstantUtils.JCR_CONTENT)).thenReturn(pageResource);
        when(pageResource.adaptTo(ModifiableValueMap.class)).thenReturn(modifiableValueMap);
        doThrow(new PersistenceException("Commit failed")).when(resourceResolver).commit();
        process.execute(workItem, workflowSession, null);
        verify(resourceResolver).commit();
    }
}
