package com.citibank.contentfactory.core.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import java.io.ByteArrayInputStream;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import javax.servlet.http.HttpServletResponse;
import com.citibank.contentfactory.core.service.SFMCService;
import com.citibank.contentfactory.core.util.ConstantUtils;
import org.apache.http.HttpEntity;
import org.apache.http.StatusLine;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.osgi.services.HttpClientBuilderFactory;
import org.apache.sling.api.SlingHttpServletResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

class POSTAPIServiceImplTest {

    @InjectMocks
    private POSTAPIServiceImpl postAPIService;

    @Mock
    private HttpClientBuilderFactory clientBuilderFactory;

    @Mock
    private SFMCService sfmcService;

    @Mock
    private CloseableHttpClient httpClient;

    @Mock
    private CloseableHttpResponse httpResponse;

    @Mock
    private SlingHttpServletResponse slingHttpServletResponse;

    @Mock
    private HttpClientBuilder clientBuilder;

    @Mock
    private StatusLine statusLine;

    @Mock
    private PrintWriter writer;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetAccessTokenPOSTAPI_Success() throws Exception {
        String payload = "{\"grant_type\":\"client_credentials\"}";
        String expectedToken = "test-access-token";
        when(sfmcService.authUrl()).thenReturn("https://citi.com/token");
        when(clientBuilderFactory.newBuilder()).thenReturn(clientBuilder);
        when(clientBuilder.build()).thenReturn(httpClient);
        when(httpResponse.getStatusLine()).thenReturn(statusLine);
        when(statusLine.getStatusCode()).thenReturn(HttpServletResponse.SC_OK);
        String jsonResponse = "{\"access_token\":\"" + expectedToken + "\"}";
        HttpEntity entity = mock(HttpEntity.class);
        when(entity.getContent()).thenReturn(new ByteArrayInputStream(jsonResponse.getBytes(StandardCharsets.UTF_8)));
        when(entity.getContentLength()).thenReturn((long) jsonResponse.length());
        when(httpResponse.getEntity()).thenReturn(entity);
        when(httpClient.execute(any(HttpPost.class))).thenReturn(httpResponse);
        String accessToken = postAPIService.getAccessTokenPOSTAPI(slingHttpServletResponse, payload);
        assertEquals(expectedToken, accessToken);
        verify(slingHttpServletResponse, never()).setStatus(HttpServletResponse.SC_BAD_REQUEST);
    }

    @Test
    void testGetPOSTAPIResponse_Success() throws Exception {
        String accessToken = "test-access-token";
        String payload = "{\"data\":\"test\"}";
        String jsonResponse = "{\"result\":\"success\"}";
        when(sfmcService.createAssetUrl()).thenReturn("https://citi.com/create-asset");
        when(clientBuilderFactory.newBuilder()).thenReturn(clientBuilder);
        when(clientBuilder.build()).thenReturn(httpClient);
        when(httpResponse.getStatusLine()).thenReturn(statusLine);
        when(statusLine.getStatusCode()).thenReturn(HttpServletResponse.SC_OK);
        HttpEntity entity = mock(HttpEntity.class);
        when(entity.getContent()).thenReturn(new ByteArrayInputStream(jsonResponse.getBytes(StandardCharsets.UTF_8)));
        when(entity.getContentLength()).thenReturn((long) jsonResponse.length());
        when(httpResponse.getEntity()).thenReturn(entity);
        when(httpClient.execute(any(HttpPost.class))).thenReturn(httpResponse);
        when(slingHttpServletResponse.getContentType()).thenReturn(ConstantUtils.APPLICATION_JSON);
        when(slingHttpServletResponse.getWriter()).thenReturn(writer);
        postAPIService.getPOSTAPIResponse(slingHttpServletResponse, accessToken, payload);
        verify(slingHttpServletResponse).setStatus(HttpServletResponse.SC_OK);
    }
}