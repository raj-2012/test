package com.citibank.contentfactory.core.models;

import static org.junit.jupiter.api.Assertions.assertEquals;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.apache.sling.api.resource.Resource;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith(AemContextExtension.class)
class PreHeaderModelTest {

    private final AemContext context = new AemContext();

    private PreHeaderModel preHeaderModel;

    @BeforeEach
    void setUp() {
        context.addModelsForClasses(PreHeaderModel.class);
        context.create().resource("/content/preheader",
                "logo", "test-logo.png",
                "text", "Welcome to Citibank",
                "viewInBrowserText", "View in Browser",
                "name", "John Doe",
                "cardMemberSinceText", "2010",
                "cardMemberSince", "1234",
                "lockIcon", "lock-icon.png",
                "accountEndingIn", "5678",
                "accountNumber", "9876543210",
                "cardImage", "card-image.png",
                "valuedCustomer", "Valued Customer",
                "color", "blue",
                "altText", "logoText",
                "title", "title",
                "browserTitle", "browserTitle",
                "lockIconAltText","lockIconAltText",
                "lockIconTitle","lockIconTitle",
                "cardImageAltText","cardImageAltText",
                "cardImageTitle","cardImageTitle");

        Resource resource = context.resourceResolver().getResource("/content/preheader");
        preHeaderModel = resource.adaptTo(PreHeaderModel.class);
    }

    @Test
    void testPreHeaderModel() {
        assertEquals("test-logo.png", preHeaderModel.getLogo());
        assertEquals("Welcome to Citibank", preHeaderModel.getText());
        assertEquals("View in Browser", preHeaderModel.getViewInBrowserText());
        assertEquals("John Doe", preHeaderModel.getName());
        assertEquals("2010", preHeaderModel.getCardMemberSinceText());
        assertEquals("1234", preHeaderModel.getCardMemberSince());
        assertEquals("lock-icon.png", preHeaderModel.getLockIcon());
        assertEquals("5678", preHeaderModel.getAccountEndingIn());
        assertEquals("9876543210", preHeaderModel.getAccountNumber());
        assertEquals("card-image.png", preHeaderModel.getCardImage());
        assertEquals("Valued Customer", preHeaderModel.getValuedCustomer());
        assertEquals("blue", preHeaderModel.getColor());
        assertEquals("logoText", preHeaderModel.getAltText());
        assertEquals("title", preHeaderModel.getTitle());
        assertEquals("browserTitle", preHeaderModel.getBrowserTitle());
        assertEquals("lockIconAltText", preHeaderModel.getLockIconAltText());
        assertEquals("lockIconTitle", preHeaderModel.getLockIconTitle());
        assertEquals("cardImageAltText", preHeaderModel.getCardImageAltText());
        assertEquals("cardImageTitle", preHeaderModel.getCardImageTitle());
    }
}
