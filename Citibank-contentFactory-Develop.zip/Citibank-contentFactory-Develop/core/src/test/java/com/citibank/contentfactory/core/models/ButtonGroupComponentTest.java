package com.citibank.contentfactory.core.models;

import java.util.HashMap;
import java.util.Map;
import java.util.List;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.apache.sling.api.resource.Resource;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith(AemContextExtension.class)
class ButtonGroupComponentTest {

    private final AemContext context = new AemContext();
    private ButtonGroupComponent buttonGroupComponent;

    @BeforeEach
    void setUp() {
        context.addModelsForClasses(ButtonGroupComponent.class);

        // Set up the properties for the main component
        Map<String, Object> properties = new HashMap<>();
        properties.put("bgColor", "blue");
        properties.put("continuousFlag", "true");

        // Create a mock resource for the ButtonGroupComponent
        Resource resource = context.create().resource("/content/test/buttongroup", properties);

        // Create mock child resources for the buttonsCard multifield
        Map<String, Object> button1Props = new HashMap<>();
        button1Props.put("link", "/link1");
        button1Props.put("text", "Button 1");
        button1Props.put("title", "Title 1");
        context.create().resource("/content/test/buttongroup/buttonsCard/0", button1Props);
        Map<String, Object> button2Props = new HashMap<>();
        button2Props.put("link", "/link2");
        button2Props.put("text", "Button 2");
        button2Props.put("title", "Title 2");
        context.create().resource("/content/test/buttongroup/buttonsCard/1", button2Props);

        // Adapt the resource to the ButtonGroupComponent Sling model
        buttonGroupComponent = resource.adaptTo(ButtonGroupComponent.class);
    }

    @Test
    void testBgColor() {
        assertNotNull(buttonGroupComponent);
        assertEquals("blue", buttonGroupComponent.getBgColor());
    }

    @Test
    void testContinuousFlag() {
        assertEquals("true", buttonGroupComponent.getContinuousFlag());
    }

    @Test
    void testButtonsCard() {
        List<ButtonGroupComponent.ButtonData> buttons = buttonGroupComponent.getButtonsCard();
        assertNotNull(buttons);
        assertEquals(2, buttons.size());

        // Verify the properties of the first button
        ButtonGroupComponent.ButtonData button1 = buttons.get(0);
        assertEquals("/link1", button1.getLink());
        assertEquals("Button 1", button1.getText());
        assertEquals("Title 1", button1.getTitle());

        // Verify the properties of the second button
        ButtonGroupComponent.ButtonData button2 = buttons.get(1);
        assertEquals("/link2", button2.getLink());
        assertEquals("Button 2", button2.getText());
        assertEquals("Title 2", button2.getTitle());
    }
}
